#!/usr/bin/env node
import bcrypt from "bcryptjs";
import pg from "pg";

const { Client } = pg;

const ADMIN_EMAIL = "admin@lifebridge.lv";
const ADMIN_PASSWORD = "admin123";
const ADMIN_NAME = "Admin";

async function main() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10);

  const existing = await client.query("SELECT id FROM users WHERE email = $1", [ADMIN_EMAIL]);
  if (existing.rowCount > 0) {
    await client.query(
      "UPDATE users SET role = 'admin', password_hash = $1, is_verified = true, is_approved = true WHERE email = $2",
      [passwordHash, ADMIN_EMAIL],
    );
    console.log(`✓ Admin user updated: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  } else {
    await client.query(
      `INSERT INTO users (email, password_hash, name, role, is_verified, is_approved)
       VALUES ($1, $2, $3, 'admin', true, true)`,
      [ADMIN_EMAIL, passwordHash, ADMIN_NAME],
    );
    console.log(`✓ Admin user created: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  }

  // Set existing seed user (id=1) password so they can also login as student
  const seedHash = await bcrypt.hash("student123", 10);
  await client.query(
    "UPDATE users SET password_hash = $1, role = COALESCE(NULLIF(role, ''), 'student'), is_approved = true WHERE id = 1 AND password_hash IS NULL",
    [seedHash],
  );
  console.log("✓ Default student account: alice@example.com / student123 (or whoever id=1 is)");

  await client.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
