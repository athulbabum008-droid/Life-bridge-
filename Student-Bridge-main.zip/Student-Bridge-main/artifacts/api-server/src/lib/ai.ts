import { logger } from "./logger";

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface ScenarioFeedback {
  tone: string;
  language: string;
  suggestion: string;
  score: number;
}

interface ScenarioChatResult {
  reply: string;
  feedback: ScenarioFeedback;
}

export async function chatWithScenarioAI(
  systemPrompt: string,
  history: ChatMessage[],
  userMessage: string
): Promise<ScenarioChatResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  
  if (!apiKey) {
    logger.warn("No OPENAI_API_KEY, using mock AI response");
    return getMockResponse(userMessage, systemPrompt);
  }

  try {
    const messages: ChatMessage[] = [
      { role: "system", content: systemPrompt },
      ...history,
      { role: "user", content: userMessage },
    ];

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json() as {
      choices: Array<{ message: { content: string } }>;
    };
    const reply = data.choices[0]?.message?.content ?? "I understand. Please continue.";

    const feedback = await generateFeedback(apiKey, userMessage, systemPrompt);

    return { reply, feedback };
  } catch (err) {
    logger.error({ err }, "AI chat error");
    return getMockResponse(userMessage, systemPrompt);
  }
}

async function generateFeedback(
  apiKey: string,
  userMessage: string,
  systemPrompt: string
): Promise<ScenarioFeedback> {
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a language coach helping international students communicate better in ${systemPrompt.includes("doctor") ? "medical" : systemPrompt.includes("interview") ? "professional" : "everyday"} situations. Analyze the student's message and provide brief feedback in JSON format.`,
          },
          {
            role: "user",
            content: `Student said: "${userMessage}"\n\nProvide feedback as JSON with fields: tone (string, e.g. "Polite", "Too casual", "Professional"), language (string, brief grammar/vocab note), suggestion (string, one improvement tip), score (integer 1-10)`,
          },
        ],
        max_tokens: 200,
        response_format: { type: "json_object" },
      }),
    });

    const data = await response.json() as {
      choices: Array<{ message: { content: string } }>;
    };
    const parsed = JSON.parse(data.choices[0]?.message?.content ?? "{}");
    return {
      tone: parsed.tone ?? "Appropriate",
      language: parsed.language ?? "Good vocabulary usage",
      suggestion: parsed.suggestion ?? "Try to be more specific",
      score: typeof parsed.score === "number" ? Math.min(10, Math.max(1, parsed.score)) : 7,
    };
  } catch {
    return {
      tone: "Appropriate",
      language: "Clear communication",
      suggestion: "Try adding more detail to your response",
      score: 7,
    };
  }
}

function getMockResponse(userMessage: string, systemPrompt: string): ScenarioChatResult {
  const isApartment = systemPrompt.toLowerCase().includes("apartment") || systemPrompt.toLowerCase().includes("rent");
  const isInterview = systemPrompt.toLowerCase().includes("interview") || systemPrompt.toLowerCase().includes("job");
  const isDoctor = systemPrompt.toLowerCase().includes("doctor") || systemPrompt.toLowerCase().includes("medical");

  let reply = "I see. Could you tell me more?";
  if (isApartment) {
    reply = "The apartment is available from the 1st of next month. It includes all utilities except electricity. Would you like to schedule a viewing?";
  } else if (isInterview) {
    reply = "That's an interesting perspective. Can you give me an example of a challenge you overcame at your previous position?";
  } else if (isDoctor) {
    reply = "I understand. How long have you been experiencing these symptoms? Have you taken any medication for it?";
  }

  const wordCount = userMessage.split(" ").length;
  const hasPoliteWords = /please|thank|would|could|kindly/i.test(userMessage);
  const score = Math.min(10, Math.max(4, wordCount + (hasPoliteWords ? 2 : 0)));

  return {
    reply,
    feedback: {
      tone: hasPoliteWords ? "Polite and professional" : "Could be more formal",
      language: wordCount > 5 ? "Good sentence structure" : "Try to elaborate more",
      suggestion: hasPoliteWords
        ? "Great use of polite language! Add more specific details."
        : 'Consider using "please" or "could you" for a more professional tone.',
      score: Math.min(10, score),
    },
  };
}
