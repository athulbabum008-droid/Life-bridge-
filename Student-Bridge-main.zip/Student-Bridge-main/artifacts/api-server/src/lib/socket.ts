import { Server } from "socket.io";
import type { Server as HttpServer } from "http";
import { logger } from "./logger";

let _io: Server | null = null;

export function createSocketServer(httpServer: HttpServer): Server {
  _io = new Server(httpServer, {
    path: "/api/socket.io",
    cors: { origin: true, credentials: true },
  });

  _io.on("connection", (socket) => {
    logger.info({ socketId: socket.id }, "Socket connected");

    socket.on("join-group", (groupId: number) => {
      socket.join(`group:${groupId}`);
    });

    socket.on("leave-group", (groupId: number) => {
      socket.leave(`group:${groupId}`);
    });

    socket.on("disconnect", () => {
      logger.info({ socketId: socket.id }, "Socket disconnected");
    });
  });

  return _io;
}

export function getSocket(): Server | null {
  return _io;
}
