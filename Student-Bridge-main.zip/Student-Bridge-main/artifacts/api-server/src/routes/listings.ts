import { Router, type IRouter } from "express";
import { eq, and, gte, lte, sql, desc } from "drizzle-orm";
import { db } from "@workspace/db";
import { listingsTable } from "@workspace/db";
import {
  GetListingsQueryParams,
  CreateListingBody,
  GetListingParams,
  UpdateListingParams,
  UpdateListingBody,
  DeleteListingParams,
  ReportListingParams,
  ReportListingBody,
  GetRecentListingsQueryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/listings/stats", async (_req, res): Promise<void> => {
  const allListings = await db
    .select()
    .from(listingsTable)
    .where(and(eq(listingsTable.isActive, true), eq(listingsTable.status, "approved")));

  const apartments = allListings.filter((l) => l.type === "apartment");
  const jobs = allListings.filter((l) => l.type === "job");

  const prices = apartments
    .map((a) => (a.price ? parseFloat(String(a.price)) : null))
    .filter((p): p is number => p !== null);

  const avgApartmentPrice = prices.length > 0 ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;

  // Count by city
  const cityMap = new Map<string, number>();
  allListings.forEach((l) => {
    cityMap.set(l.city, (cityMap.get(l.city) ?? 0) + 1);
  });
  const cityCounts = Array.from(cityMap.entries()).map(([city, count]) => ({ city, count }));

  // Recent activity (last 7 days)
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const recentActivity = allListings.filter((l) => l.createdAt > weekAgo).length;

  res.json({
    totalApartments: apartments.length,
    totalJobs: jobs.length,
    avgApartmentPrice: Math.round(avgApartmentPrice),
    cityCounts,
    recentActivity,
  });
});

router.get("/listings/recent", async (req, res): Promise<void> => {
  const parsed = GetRecentListingsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 10) : 10;

  const listings = await db
    .select()
    .from(listingsTable)
    .where(and(eq(listingsTable.isActive, true), eq(listingsTable.status, "approved")))
    .orderBy(desc(listingsTable.createdAt))
    .limit(limit);

  res.json(listings.map(formatListing));
});

router.get("/listings", async (req, res): Promise<void> => {
  const parsed = GetListingsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { type, city, minPrice, maxPrice, source, limit, offset } = parsed.data;

  let query = db.select().from(listingsTable).where(eq(listingsTable.isActive, true));

  // We'll build conditions array and apply
  const conditions = [eq(listingsTable.isActive, true), eq(listingsTable.status, "approved")];

  if (type && type !== "all") {
    conditions.push(eq(listingsTable.type, type));
  }
  if (city) {
    conditions.push(eq(listingsTable.city, city));
  }
  if (source && source !== "all") {
    conditions.push(eq(listingsTable.source, source));
  }

  const listings = await db
    .select()
    .from(listingsTable)
    .where(and(...conditions))
    .orderBy(desc(listingsTable.createdAt))
    .limit(limit ?? 50)
    .offset(offset ?? 0);

  let filtered = listings;

  if (minPrice !== undefined) {
    filtered = filtered.filter((l) => !l.price || parseFloat(String(l.price)) >= (minPrice as number));
  }
  if (maxPrice !== undefined) {
    filtered = filtered.filter((l) => !l.price || parseFloat(String(l.price)) <= (maxPrice as number));
  }

  // Get total count
  const total = await db
    .select({ count: sql<number>`count(*)` })
    .from(listingsTable)
    .where(and(...conditions));

  res.json({
    listings: filtered.map(formatListing),
    total: Number(total[0]?.count ?? 0),
  });
});

router.post("/listings", async (req, res): Promise<void> => {
  if (!req.session.userId) {
    res.status(401).json({ error: "You must be signed in to post a listing" });
    return;
  }
  const parsed = CreateListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const role = req.session.role;
  if (role !== "uploader" && role !== "admin") {
    res.status(403).json({ error: "Only uploaders and admins can post listings" });
    return;
  }

  // Admins auto-approve, uploaders go to pending
  const status = role === "admin" ? "approved" : "pending";

  const [listing] = await db
    .insert(listingsTable)
    .values({
      ...parsed.data,
      currency: parsed.data.currency ?? "EUR",
      images: parsed.data.images ?? [],
      source: "user",
      userId: req.session.userId,
      status,
    })
    .returning();

  res.status(201).json(formatListing(listing));
});

// Uploader's own listings (any status)
router.get("/my-listings", async (req, res): Promise<void> => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }
  const listings = await db
    .select()
    .from(listingsTable)
    .where(eq(listingsTable.userId, req.session.userId))
    .orderBy(desc(listingsTable.createdAt));
  res.json(listings.map(formatListing));
});

router.get("/listings/:id", async (req, res): Promise<void> => {
  const params = GetListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, params.data.id));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  res.json(formatListing(listing));
});

router.patch("/listings/:id", async (req, res): Promise<void> => {
  if (!req.session.userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const params = UpdateListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateListingBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(listingsTable)
    .where(eq(listingsTable.id, params.data.id));

  if (!existing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  const isAdmin = req.session.role === "admin";
  const isOwner = existing.userId === req.session.userId;
  if (!isAdmin && !isOwner) {
    res.status(403).json({ error: "You can only edit your own listings" });
    return;
  }

  const [listing] = await db
    .update(listingsTable)
    .set({ ...body.data, updatedAt: new Date() })
    .where(eq(listingsTable.id, params.data.id))
    .returning();

  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  res.json(formatListing(listing));
});

router.delete("/listings/:id", async (req, res): Promise<void> => {
  const params = DeleteListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [listing] = await db
    .delete(listingsTable)
    .where(eq(listingsTable.id, params.data.id))
    .returning();

  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/listings/:id/report", async (req, res): Promise<void> => {
  const params = ReportListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = ReportListingBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [listing] = await db
    .update(listingsTable)
    .set({ reportCount: sql`${listingsTable.reportCount} + 1` })
    .where(eq(listingsTable.id, params.data.id))
    .returning();

  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  // Auto-hide listings with 5+ reports
  if (listing.reportCount >= 5) {
    await db.update(listingsTable).set({ isActive: false }).where(eq(listingsTable.id, params.data.id));
  }

  res.json({ message: "Listing reported successfully" });
});

function formatListing(l: typeof listingsTable.$inferSelect) {
  return {
    ...l,
    price: l.price !== null ? parseFloat(String(l.price)) : null,
    images: Array.isArray(l.images) ? l.images : [],
    createdAt: l.createdAt.toISOString(),
    updatedAt: l.updatedAt.toISOString(),
  };
}

export default router;
