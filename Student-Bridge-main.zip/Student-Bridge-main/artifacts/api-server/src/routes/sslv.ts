import { Router, type IRouter } from "express";
import { fetchSslvApartments, fetchSslvJobs } from "../lib/sslv";
import {
  GetSslvApartmentsQueryParams,
  GetSslvJobsQueryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/sslv/apartments", async (req, res): Promise<void> => {
  const parsed = GetSslvApartmentsQueryParams.safeParse(req.query);
  const city = parsed.success ? (parsed.data.city ?? "riga") : "riga";
  const maxPrice = parsed.success ? parsed.data.maxPrice : undefined;

  const listings = await fetchSslvApartments(city, maxPrice);
  res.json(listings);
});

router.get("/sslv/jobs", async (req, res): Promise<void> => {
  const parsed = GetSslvJobsQueryParams.safeParse(req.query);
  const city = parsed.success ? (parsed.data.city ?? "riga") : "riga";
  const category = parsed.success ? parsed.data.category : undefined;

  const listings = await fetchSslvJobs(city, category);
  res.json(listings);
});

export default router;
