import { Router, type IRouter } from "express";
import { eq, or, and, desc, sql, inArray } from "drizzle-orm";
import { db } from "@workspace/db";
import { conversationsTable, messagesTable, groupsTable, usersTable, messageReadsTable } from "@workspace/db";
import {
  GetConversationsQueryParams,
  CreateConversationBody,
  GetMessagesParams,
  GetMessagesQueryParams,
  SendMessageParams,
  SendMessageBody,
  GetGroupMessagesParams,
  SendGroupMessageParams,
  SendGroupMessageBody,
} from "@workspace/api-zod";
import { getSocket } from "../lib/socket";

const router: IRouter = Router();

// Conversations
router.get("/conversations", async (req, res): Promise<void> => {
  const parsed = GetConversationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { userId } = parsed.data;

  const convs = await db
    .select()
    .from(conversationsTable)
    .where(
      or(
        eq(conversationsTable.participant1Id, userId),
        eq(conversationsTable.participant2Id, userId)
      )
    )
    .orderBy(desc(conversationsTable.updatedAt));

  const result = await Promise.all(
    convs.map(async (c) => {
      const [p1] = await db.select().from(usersTable).where(eq(usersTable.id, c.participant1Id));
      const [p2] = await db.select().from(usersTable).where(eq(usersTable.id, c.participant2Id));
      return {
        ...c,
        updatedAt: c.updatedAt.toISOString(),
        participant1: p1 ?? null,
        participant2: p2 ?? null,
      };
    })
  );

  res.json(result);
});

router.post("/conversations", async (req, res): Promise<void> => {
  const parsed = CreateConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { participant1Id, participant2Id, listingId } = parsed.data;

  const [existing] = await db
    .select()
    .from(conversationsTable)
    .where(
      or(
        and(
          eq(conversationsTable.participant1Id, participant1Id),
          eq(conversationsTable.participant2Id, participant2Id)
        ),
        and(
          eq(conversationsTable.participant1Id, participant2Id),
          eq(conversationsTable.participant2Id, participant1Id)
        )
      )
    );

  if (existing) {
    const [p1] = await db.select().from(usersTable).where(eq(usersTable.id, existing.participant1Id));
    const [p2] = await db.select().from(usersTable).where(eq(usersTable.id, existing.participant2Id));
    res.status(201).json({
      ...existing,
      updatedAt: existing.updatedAt.toISOString(),
      participant1: p1 ?? null,
      participant2: p2 ?? null,
    });
    return;
  }

  const [conv] = await db
    .insert(conversationsTable)
    .values({ participant1Id, participant2Id, listingId: listingId ?? null })
    .returning();

  const [p1] = await db.select().from(usersTable).where(eq(usersTable.id, participant1Id));
  const [p2] = await db.select().from(usersTable).where(eq(usersTable.id, participant2Id));

  res.status(201).json({
    ...conv,
    updatedAt: conv.updatedAt.toISOString(),
    participant1: p1 ?? null,
    participant2: p2 ?? null,
  });
});

// Messages in conversation
router.get("/conversations/:id/messages", async (req, res): Promise<void> => {
  const params = GetMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const queryParsed = GetMessagesQueryParams.safeParse(req.query);
  const limit = queryParsed.success ? (queryParsed.data.limit ?? 50) : 50;
  const offset = queryParsed.success ? (queryParsed.data.offset ?? 0) : 0;

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, params.data.id))
    .orderBy(messagesTable.createdAt)
    .limit(limit)
    .offset(offset);

  const result = await Promise.all(
    messages.map(async (m) => {
      const [sender] = await db.select().from(usersTable).where(eq(usersTable.id, m.senderId));
      return {
        ...m,
        createdAt: m.createdAt.toISOString(),
        sender: sender ?? null,
      };
    })
  );

  res.json(result);
});

router.post("/conversations/:id/messages", async (req, res): Promise<void> => {
  const params = SendMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = SendMessageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [message] = await db
    .insert(messagesTable)
    .values({
      conversationId: params.data.id,
      senderId: body.data.senderId,
      content: body.data.content,
    })
    .returning();

  await db
    .update(conversationsTable)
    .set({ lastMessage: body.data.content, updatedAt: new Date() })
    .where(eq(conversationsTable.id, params.data.id));

  const [sender] = await db.select().from(usersTable).where(eq(usersTable.id, body.data.senderId));

  const payload = {
    ...message,
    createdAt: message.createdAt.toISOString(),
    sender: sender ?? null,
  };

  // Broadcast to conversation room
  getSocket()?.to(`conv:${params.data.id}`).emit("conv-message", payload);

  res.status(201).json(payload);
});

// ─── Admin contact helper ─────────────────────────────────────────────────────
router.get("/admin-contact", async (_req, res): Promise<void> => {
  const [admin] = await db
    .select({ id: usersTable.id, name: usersTable.name })
    .from(usersTable)
    .where(eq(usersTable.role, "admin"))
    .limit(1);
  if (!admin) {
    res.status(404).json({ error: "No admin user found" });
    return;
  }
  res.json({ adminId: admin.id, adminName: admin.name });
});

// Groups
router.get("/groups", async (_req, res): Promise<void> => {
  const groups = await db.select().from(groupsTable).orderBy(desc(groupsTable.memberCount));
  res.json(groups.map((g) => ({ ...g, createdAt: g.createdAt.toISOString() })));
});

router.get("/groups/:id/messages", async (req, res): Promise<void> => {
  const params = GetGroupMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.groupId, params.data.id))
    .orderBy(messagesTable.createdAt)
    .limit(100);

  const result = await Promise.all(
    messages.map(async (m) => {
      const [sender] = await db.select().from(usersTable).where(eq(usersTable.id, m.senderId));
      return {
        ...m,
        createdAt: m.createdAt.toISOString(),
        sender: sender ?? null,
      };
    })
  );

  res.json(result);
});

// ─── Read receipts ────────────────────────────────────────────────────────────

// Mark all messages in a group as read by a user
router.post("/groups/:id/read", async (req, res): Promise<void> => {
  const groupId = Number(req.params["id"]);
  const userId = Number(req.body.userId);
  if (!groupId || !userId) { res.status(400).json({ error: "Missing fields" }); return; }

  const msgs = await db
    .select({ id: messagesTable.id })
    .from(messagesTable)
    .where(eq(messagesTable.groupId, groupId));

  if (msgs.length === 0) { res.json({ ok: true }); return; }

  const values = msgs.map((m) => ({ messageId: m.id, userId }));
  await db.insert(messageReadsTable).values(values).onConflictDoNothing();

  // Broadcast updated read counts to the group room
  const counts = await db
    .select({ messageId: messageReadsTable.messageId, count: sql<number>`count(*)`.mapWith(Number) })
    .from(messageReadsTable)
    .where(inArray(messageReadsTable.messageId, msgs.map((m) => m.id)))
    .groupBy(messageReadsTable.messageId);

  const countMap: Record<number, number> = {};
  for (const row of counts) countMap[row.messageId] = row.count;

  getSocket()?.to(`group:${groupId}`).emit("read-update", { groupId, counts: countMap });

  res.json({ ok: true, counts: countMap });
});

// Get read counts for messages in a group
router.get("/groups/:id/read-counts", async (req, res): Promise<void> => {
  const groupId = Number(req.params["id"]);
  if (!groupId) { res.status(400).json({ error: "Missing id" }); return; }

  const msgs = await db
    .select({ id: messagesTable.id })
    .from(messagesTable)
    .where(eq(messagesTable.groupId, groupId));

  if (msgs.length === 0) { res.json({}); return; }

  const counts = await db
    .select({ messageId: messageReadsTable.messageId, count: sql<number>`count(*)`.mapWith(Number) })
    .from(messageReadsTable)
    .where(inArray(messageReadsTable.messageId, msgs.map((m) => m.id)))
    .groupBy(messageReadsTable.messageId);

  const countMap: Record<number, number> = {};
  for (const row of counts) countMap[row.messageId] = row.count;
  res.json(countMap);
});

router.post("/groups/:id/messages", async (req, res): Promise<void> => {
  const params = SendGroupMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = SendGroupMessageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [message] = await db
    .insert(messagesTable)
    .values({
      groupId: params.data.id,
      senderId: body.data.senderId,
      content: body.data.content,
    })
    .returning();

  const [sender] = await db.select().from(usersTable).where(eq(usersTable.id, body.data.senderId));

  const payload = {
    ...message,
    createdAt: message.createdAt.toISOString(),
    sender: sender ?? null,
  };

  // Broadcast to all clients in this group room (excluding sender)
  getSocket()?.to(`group:${params.data.id}`).emit("group-message", payload);

  res.status(201).json(payload);
});

export default router;
