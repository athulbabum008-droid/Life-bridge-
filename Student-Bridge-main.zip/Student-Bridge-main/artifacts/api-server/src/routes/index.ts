import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import adminRouter from "./admin";
import usersRouter from "./users";
import listingsRouter from "./listings";
import sslvRouter from "./sslv";
import messagesRouter from "./messages";
import scenariosRouter from "./scenarios";
import culturalRouter from "./cultural";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(adminRouter);
router.use(usersRouter);
router.use(listingsRouter);
router.use(sslvRouter);
router.use(messagesRouter);
router.use(scenariosRouter);
router.use(culturalRouter);

export default router;
