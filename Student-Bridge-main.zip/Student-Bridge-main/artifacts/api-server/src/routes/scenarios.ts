import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db } from "@workspace/db";
import { scenariosTable, scenarioProgressTable } from "@workspace/db";
import { chatWithScenarioAI } from "../lib/ai";
import {
  ChatWithScenarioParams,
  ChatWithScenarioBody,
  GetScenarioProgressQueryParams,
  SaveScenarioProgressBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/scenarios", async (_req, res): Promise<void> => {
  const scenarios = await db.select().from(scenariosTable);
  res.json(scenarios);
});

router.post("/scenarios/:id/chat", async (req, res): Promise<void> => {
  const params = ChatWithScenarioParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = ChatWithScenarioBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [scenario] = await db
    .select()
    .from(scenariosTable)
    .where(eq(scenariosTable.id, params.data.id));

  if (!scenario) {
    res.status(404).json({ error: "Scenario not found" });
    return;
  }

  const history = (body.data.history ?? []).map((h) => ({
    role: h.role as "user" | "assistant",
    content: h.content,
  }));

  const result = await chatWithScenarioAI(scenario.systemPrompt, history, body.data.message);

  res.json(result);
});

router.get("/scenarios/progress", async (req, res): Promise<void> => {
  const parsed = GetScenarioProgressQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const progress = await db
    .select()
    .from(scenarioProgressTable)
    .where(eq(scenarioProgressTable.userId, parsed.data.userId));

  res.json(
    progress.map((p) => ({
      ...p,
      completedAt: p.completedAt?.toISOString() ?? null,
    }))
  );
});

router.post("/scenarios/progress", async (req, res): Promise<void> => {
  const parsed = SaveScenarioProgressBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { userId, scenarioId, completedAt, totalMessages, lastScore } = parsed.data;

  // Upsert progress
  const [existing] = await db
    .select()
    .from(scenarioProgressTable)
    .where(
      eq(scenarioProgressTable.userId, userId)
    );

  let progress;
  if (existing) {
    [progress] = await db
      .update(scenarioProgressTable)
      .set({
        totalMessages,
        lastScore: lastScore ?? null,
        completedAt: completedAt ? new Date(completedAt) : null,
      })
      .where(eq(scenarioProgressTable.id, existing.id))
      .returning();
  } else {
    [progress] = await db
      .insert(scenarioProgressTable)
      .values({
        userId,
        scenarioId,
        totalMessages,
        lastScore: lastScore ?? null,
        completedAt: completedAt ? new Date(completedAt) : null,
      })
      .returning();
  }

  res.json({
    ...progress,
    completedAt: progress.completedAt?.toISOString() ?? null,
  });
});

export default router;
