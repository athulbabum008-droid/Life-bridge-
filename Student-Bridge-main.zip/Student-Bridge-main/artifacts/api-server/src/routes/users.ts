import { Router, type IRouter } from "express";
import { eq, and, ne, inArray } from "drizzle-orm";
import { db } from "@workspace/db";
import { usersTable, followsTable } from "@workspace/db";
import {
  CreateUserBody,
  GetUserParams,
  UpdateUserParams,
  UpdateUserBody,
  GetMatchedUsersQueryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/users", async (req, res): Promise<void> => {
  const parsed = CreateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, name, avatar, country, university, bio } = parsed.data;

  // Upsert: find existing or create
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));

  if (existing) {
    const [updated] = await db
      .update(usersTable)
      .set({ name, avatar, country, university, bio })
      .where(eq(usersTable.email, email))
      .returning();
    res.status(201).json(updated);
    return;
  }

  const [user] = await db
    .insert(usersTable)
    .values({ email, name, avatar: avatar ?? null, country: country ?? null, university: university ?? null, bio: bio ?? null })
    .returning();

  res.status(201).json(user);
});

router.get("/users/match", async (req, res): Promise<void> => {
  const parsed = GetMatchedUsersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { userId, limit } = parsed.data;

  // Get current user's country/university
  const [currentUser] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!currentUser) {
    res.json([]);
    return;
  }

  // Find users with matching country or university
  const users = await db
    .select()
    .from(usersTable)
    .where(ne(usersTable.id, userId))
    .limit(limit ?? 20);

  res.json(users);
});

router.get("/users/:id", async (req, res): Promise<void> => {
  const params = GetUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(user);
});

router.patch("/users/:id", async (req, res): Promise<void> => {
  const params = UpdateUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateUserBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set(body.data)
    .where(eq(usersTable.id, params.data.id))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(user);
});

// ─── Follow / Unfollow ───────────────────────────────────────────────────────

router.post("/follows", async (req, res): Promise<void> => {
  const { followerId, followingId } = req.body as { followerId: number; followingId: number };
  if (!followerId || !followingId || followerId === followingId) {
    res.status(400).json({ error: "Invalid follow request" });
    return;
  }
  try {
    await db.insert(followsTable).values({ followerId, followingId }).onConflictDoNothing();
    res.status(201).json({ success: true });
  } catch {
    res.status(500).json({ error: "Failed to follow" });
  }
});

router.delete("/follows", async (req, res): Promise<void> => {
  const { followerId, followingId } = req.body as { followerId: number; followingId: number };
  if (!followerId || !followingId) {
    res.status(400).json({ error: "Invalid unfollow request" });
    return;
  }
  await db
    .delete(followsTable)
    .where(and(eq(followsTable.followerId, followerId), eq(followsTable.followingId, followingId)));
  res.json({ success: true });
});

router.get("/follows/check", async (req, res): Promise<void> => {
  const followerId = Number(req.query["followerId"]);
  const followingId = Number(req.query["followingId"]);
  if (!followerId || !followingId) {
    res.status(400).json({ error: "Missing params" });
    return;
  }
  const [row] = await db
    .select()
    .from(followsTable)
    .where(and(eq(followsTable.followerId, followerId), eq(followsTable.followingId, followingId)));
  res.json({ isFollowing: !!row });
});

// Mutual follows — people who both follow each other
router.get("/follows/mutual", async (req, res): Promise<void> => {
  const userId = Number(req.query["userId"]);
  if (!userId) {
    res.status(400).json({ error: "Missing userId" });
    return;
  }

  const following = await db
    .select({ id: followsTable.followingId })
    .from(followsTable)
    .where(eq(followsTable.followerId, userId));

  if (following.length === 0) { res.json([]); return; }

  const followingIds = following.map((f) => f.id);

  const mutual = await db
    .select({ id: followsTable.followerId })
    .from(followsTable)
    .where(and(inArray(followsTable.followerId, followingIds), eq(followsTable.followingId, userId)));

  if (mutual.length === 0) { res.json([]); return; }

  const mutualIds = mutual.map((m) => m.id);
  const users = await db.select().from(usersTable).where(inArray(usersTable.id, mutualIds));
  res.json(users);
});

router.get("/users/:id/following", async (req, res): Promise<void> => {
  const id = Number(req.params["id"]);
  const rows = await db.select({ userId: followsTable.followingId }).from(followsTable).where(eq(followsTable.followerId, id));
  const ids = rows.map((r) => r.userId);
  if (ids.length === 0) { res.json([]); return; }
  const users = await db.select().from(usersTable).where(inArray(usersTable.id, ids));
  res.json(users);
});

router.get("/users/:id/followers", async (req, res): Promise<void> => {
  const id = Number(req.params["id"]);
  const rows = await db.select({ userId: followsTable.followerId }).from(followsTable).where(eq(followsTable.followingId, id));
  const ids = rows.map((r) => r.userId);
  if (ids.length === 0) { res.json([]); return; }
  const users = await db.select().from(usersTable).where(inArray(usersTable.id, ids));
  res.json(users);
});

export default router;
