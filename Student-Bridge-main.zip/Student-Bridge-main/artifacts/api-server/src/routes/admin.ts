import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  usersTable,
  listingsTable,
  culturalTipsTable,
  groupsTable,
  messagesTable,
  conversationsTable,
} from "@workspace/db";
import {
  ApproveUserParams,
  ApproveListingParams,
  ApproveListingBody,
  UpdateUserRoleBody,
  GetAdminListingsQueryParams,
  CreateCulturalTipBody,
  UpdateCulturalTipParams,
  UpdateCulturalTipBody,
} from "@workspace/api-zod";
import { requireRole } from "../lib/session";

const router: IRouter = Router();

const adminOnly = requireRole("admin");

// ─── DASHBOARD STATS ─────────────────────────────────────────────────────────
router.get("/admin/stats", adminOnly, async (_req, res): Promise<void> => {
  const allUsers = await db.select().from(usersTable);
  const allListings = await db.select().from(listingsTable);
  const allGroups = await db.select().from(groupsTable);
  const allMessages = await db.select().from(messagesTable);
  const allConversations = await db.select().from(conversationsTable);
  res.json({
    totalUsers: allUsers.length,
    totalStudents: allUsers.filter((u) => u.role === "student").length,
    totalUploaders: allUsers.filter((u) => u.role === "uploader").length,
    pendingUploaders: allUsers.filter((u) => u.role === "uploader" && !u.isApproved).length,
    totalListings: allListings.length,
    pendingListings: allListings.filter((l) => l.status === "pending").length,
    approvedListings: allListings.filter((l) => l.status === "approved").length,
    rejectedListings: allListings.filter((l) => l.status === "rejected").length,
    totalGroups: allGroups.length,
    totalMessages: allMessages.length,
    totalConversations: allConversations.length,
  });
});

// ─── OVERVIEW (recent activity) ───────────────────────────────────────────────
router.get("/admin/overview", adminOnly, async (_req, res): Promise<void> => {
  const recentUsers = await db
    .select()
    .from(usersTable)
    .orderBy(desc(usersTable.createdAt))
    .limit(8);

  const recentListings = await db
    .select()
    .from(listingsTable)
    .orderBy(desc(listingsTable.createdAt))
    .limit(8);

  const recentMessages = await db
    .select()
    .from(messagesTable)
    .orderBy(desc(messagesTable.createdAt))
    .limit(10);

  const messagesWithSender = await Promise.all(
    recentMessages.map(async (m) => {
      const [sender] = await db.select().from(usersTable).where(eq(usersTable.id, m.senderId));
      let groupName: string | null = null;
      if (m.groupId) {
        const [grp] = await db.select().from(groupsTable).where(eq(groupsTable.id, m.groupId));
        groupName = grp?.name ?? null;
      }
      return {
        ...m,
        createdAt: m.createdAt.toISOString(),
        senderName: sender?.name ?? "Unknown",
        groupName,
      };
    })
  );

  res.json({
    recentUsers: recentUsers.map(({ passwordHash, ...u }) => u),
    recentListings,
    recentMessages: messagesWithSender,
  });
});

// ─── USERS MANAGEMENT ────────────────────────────────────────────────────────
router.get("/admin/users", adminOnly, async (_req, res): Promise<void> => {
  const users = await db.select().from(usersTable).orderBy(desc(usersTable.createdAt));
  const safe = users.map(({ passwordHash, ...u }) => u);
  res.json(safe);
});

router.post("/admin/users/:id/approve", adminOnly, async (req, res): Promise<void> => {
  const params = ApproveUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [user] = await db
    .update(usersTable)
    .set({ isApproved: true })
    .where(eq(usersTable.id, params.data.id))
    .returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const { passwordHash, ...safe } = user;
  res.json(safe);
});

router.patch("/admin/users/:id/role", adminOnly, async (req, res): Promise<void> => {
  const params = ApproveUserParams.safeParse(req.params);
  const body = UpdateUserRoleBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [user] = await db
    .update(usersTable)
    .set({ role: body.data.role, isApproved: true, isVerified: body.data.role === "admin" ? true : undefined })
    .where(eq(usersTable.id, params.data.id))
    .returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const { passwordHash, ...safe } = user;
  res.json(safe);
});

router.delete("/admin/users/:id", adminOnly, async (req, res): Promise<void> => {
  const params = ApproveUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await db.delete(usersTable).where(eq(usersTable.id, params.data.id));
  res.json({ success: true });
});

// ─── LISTINGS MANAGEMENT ─────────────────────────────────────────────────────
router.get("/admin/listings", adminOnly, async (req, res): Promise<void> => {
  const parsed = GetAdminListingsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let listings = await db.select().from(listingsTable).orderBy(desc(listingsTable.createdAt));
  if (parsed.data.status) {
    listings = listings.filter((l) => l.status === parsed.data.status);
  }
  res.json(listings);
});

router.post("/admin/listings/:id/approve", adminOnly, async (req, res): Promise<void> => {
  const params = ApproveListingParams.safeParse(req.params);
  const body = ApproveListingBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [listing] = await db
    .update(listingsTable)
    .set({
      status: body.data.approve ? "approved" : "rejected",
      rejectionReason: body.data.approve ? null : body.data.reason ?? null,
      updatedAt: new Date(),
    })
    .where(eq(listingsTable.id, params.data.id))
    .returning();
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  res.json(listing);
});

router.delete("/admin/listings/:id", adminOnly, async (req, res): Promise<void> => {
  const params = ApproveListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await db.delete(listingsTable).where(eq(listingsTable.id, params.data.id));
  res.json({ success: true });
});

// ─── GROUPS MANAGEMENT ───────────────────────────────────────────────────────
router.get("/admin/groups", adminOnly, async (_req, res): Promise<void> => {
  const groups = await db.select().from(groupsTable).orderBy(desc(groupsTable.memberCount));
  const withCounts = await Promise.all(
    groups.map(async (g) => {
      const msgs = await db.select().from(messagesTable).where(eq(messagesTable.groupId, g.id));
      return { ...g, createdAt: g.createdAt.toISOString(), messageCount: msgs.length };
    })
  );
  res.json(withCounts);
});

router.get("/admin/groups/:id/messages", adminOnly, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.groupId, id))
    .orderBy(desc(messagesTable.createdAt))
    .limit(100);

  const result = await Promise.all(
    messages.map(async (m) => {
      const [sender] = await db.select().from(usersTable).where(eq(usersTable.id, m.senderId));
      return { ...m, createdAt: m.createdAt.toISOString(), senderName: sender?.name ?? "Unknown", senderRole: sender?.role ?? "student" };
    })
  );
  res.json(result);
});

router.delete("/admin/groups/:groupId/messages/:msgId", adminOnly, async (req, res): Promise<void> => {
  const groupId = parseInt(req.params.groupId);
  const msgId = parseInt(req.params.msgId);
  if (isNaN(groupId) || isNaN(msgId)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(messagesTable).where(eq(messagesTable.id, msgId));
  res.json({ success: true });
});

router.delete("/admin/groups/:id", adminOnly, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(messagesTable).where(eq(messagesTable.groupId, id));
  await db.delete(groupsTable).where(eq(groupsTable.id, id));
  res.json({ success: true });
});

// ─── CONVERSATIONS / DIRECT MESSAGES ─────────────────────────────────────────
router.get("/admin/conversations", adminOnly, async (_req, res): Promise<void> => {
  const convs = await db.select().from(conversationsTable).orderBy(desc(conversationsTable.updatedAt));

  const result = await Promise.all(
    convs.map(async (c) => {
      const [p1] = await db.select().from(usersTable).where(eq(usersTable.id, c.participant1Id));
      const [p2] = await db.select().from(usersTable).where(eq(usersTable.id, c.participant2Id));
      const msgs = await db.select().from(messagesTable).where(eq(messagesTable.conversationId, c.id));
      return {
        ...c,
        updatedAt: c.updatedAt.toISOString(),
        participant1Name: p1?.name ?? "Unknown",
        participant2Name: p2?.name ?? "Unknown",
        participant1Role: p1?.role ?? "student",
        participant2Role: p2?.role ?? "student",
        messageCount: msgs.length,
      };
    })
  );
  res.json(result);
});

router.delete("/admin/conversations/:convId/messages/:msgId", adminOnly, async (req, res): Promise<void> => {
  const msgId = parseInt(req.params.msgId);
  if (isNaN(msgId)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(messagesTable).where(eq(messagesTable.id, msgId));
  res.json({ success: true });
});

// ─── CULTURAL TIPS MANAGEMENT ────────────────────────────────────────────────
router.post("/admin/cultural-tips", adminOnly, async (req, res): Promise<void> => {
  const parsed = CreateCulturalTipBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [tip] = await db.insert(culturalTipsTable).values(parsed.data).returning();
  res.status(201).json(tip);
});

router.patch("/admin/cultural-tips/:id", adminOnly, async (req, res): Promise<void> => {
  const params = UpdateCulturalTipParams.safeParse(req.params);
  const body = UpdateCulturalTipBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [tip] = await db
    .update(culturalTipsTable)
    .set(body.data)
    .where(eq(culturalTipsTable.id, params.data.id))
    .returning();
  if (!tip) {
    res.status(404).json({ error: "Tip not found" });
    return;
  }
  res.json(tip);
});

router.delete("/admin/cultural-tips/:id", adminOnly, async (req, res): Promise<void> => {
  const params = UpdateCulturalTipParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  await db.delete(culturalTipsTable).where(eq(culturalTipsTable.id, params.data.id));
  res.json({ success: true });
});

export default router;
