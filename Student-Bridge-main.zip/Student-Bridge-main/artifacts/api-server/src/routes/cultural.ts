import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db } from "@workspace/db";
import { culturalTipsTable, checklistItemsTable, bookmarksTable, listingsTable, usersTable } from "@workspace/db";
import {
  GetCulturalTipsQueryParams,
  GetChecklistQueryParams,
  UpdateChecklistItemParams,
  UpdateChecklistItemBody,
  GetBookmarksQueryParams,
  AddBookmarkBody,
  RemoveBookmarkParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

// Cultural tips
router.get("/cultural-tips", async (req, res): Promise<void> => {
  const parsed = GetCulturalTipsQueryParams.safeParse(req.query);

  let tips = await db.select().from(culturalTipsTable);

  if (parsed.success) {
    if (parsed.data.country) {
      tips = tips.filter((t) => t.country === parsed.data.country || t.country === "global");
    }
    if (parsed.data.category) {
      tips = tips.filter((t) => t.category === parsed.data.category);
    }
  }

  res.json(tips);
});

// Checklist
router.get("/checklist", async (req, res): Promise<void> => {
  const parsed = GetChecklistQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const items = await db
    .select()
    .from(checklistItemsTable)
    .where(eq(checklistItemsTable.userId, parsed.data.userId))
    .orderBy(checklistItemsTable.order);

  res.json(
    items.map((i) => ({
      ...i,
      completedAt: i.completedAt?.toISOString() ?? null,
    }))
  );
});

router.patch("/checklist/:id", async (req, res): Promise<void> => {
  const params = UpdateChecklistItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateChecklistItemBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [item] = await db
    .update(checklistItemsTable)
    .set({
      isCompleted: body.data.isCompleted,
      completedAt: body.data.isCompleted ? new Date() : null,
    })
    .where(eq(checklistItemsTable.id, params.data.id))
    .returning();

  if (!item) {
    res.status(404).json({ error: "Checklist item not found" });
    return;
  }

  res.json({
    ...item,
    completedAt: item.completedAt?.toISOString() ?? null,
  });
});

// Bookmarks
router.get("/bookmarks", async (req, res): Promise<void> => {
  const parsed = GetBookmarksQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const bookmarks = await db
    .select()
    .from(bookmarksTable)
    .where(eq(bookmarksTable.userId, parsed.data.userId));

  const result = await Promise.all(
    bookmarks.map(async (b) => {
      const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, b.listingId));
      return {
        ...b,
        createdAt: b.createdAt.toISOString(),
        listing: listing
          ? {
              ...listing,
              price: listing.price !== null ? parseFloat(String(listing.price)) : null,
              images: Array.isArray(listing.images) ? listing.images : [],
              createdAt: listing.createdAt.toISOString(),
              updatedAt: listing.updatedAt.toISOString(),
            }
          : null,
      };
    })
  );

  res.json(result.filter((b) => b.listing !== null));
});

router.post("/bookmarks", async (req, res): Promise<void> => {
  const parsed = AddBookmarkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { userId, listingId } = parsed.data;

  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, listingId));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  const [bookmark] = await db
    .insert(bookmarksTable)
    .values({ userId, listingId })
    .returning();

  res.status(201).json({
    ...bookmark,
    createdAt: bookmark.createdAt.toISOString(),
    listing: {
      ...listing,
      price: listing.price !== null ? parseFloat(String(listing.price)) : null,
      images: Array.isArray(listing.images) ? listing.images : [],
      createdAt: listing.createdAt.toISOString(),
      updatedAt: listing.updatedAt.toISOString(),
    },
  });
});

router.delete("/bookmarks/:id", async (req, res): Promise<void> => {
  const params = RemoveBookmarkParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [bookmark] = await db
    .delete(bookmarksTable)
    .where(eq(bookmarksTable.id, params.data.id))
    .returning();

  if (!bookmark) {
    res.status(404).json({ error: "Bookmark not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
