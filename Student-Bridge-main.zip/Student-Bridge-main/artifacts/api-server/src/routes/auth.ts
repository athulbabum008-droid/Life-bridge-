import { Router, type IRouter } from "express";
import { eq, or } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import {
  RegisterUserBody,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/session";
import { z } from "zod";

const router: IRouter = Router();

function sanitizeUser(user: typeof usersTable.$inferSelect) {
  const { passwordHash, ...rest } = user;
  return rest;
}

// Flexible login body: must have password + at least one of email/phone
const LoginBody = z.object({
  email: z.string().optional(),
  phone: z.string().optional(),
  password: z.string(),
}).refine((d) => d.email || d.phone, {
  message: "Either email or phone is required",
});

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, phone, password, name, role, country, university, bio } = parsed.data as typeof parsed.data & { phone?: string };
  const finalRole = role === "uploader" ? "uploader" : "student";

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing) {
    res.status(409).json({ error: "Email already registered" });
    return;
  }

  if (phone) {
    const [existingPhone] = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
    if (existingPhone) {
      res.status(409).json({ error: "Phone number already registered" });
      return;
    }
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const [user] = await db
    .insert(usersTable)
    .values({
      email,
      phone: phone ?? null,
      passwordHash,
      name,
      role: finalRole,
      country: country ?? null,
      university: university ?? null,
      bio: bio ?? null,
      isApproved: finalRole === "uploader" ? false : true,
    })
    .returning();

  if (!user) {
    res.status(500).json({ error: "Failed to create user" });
    return;
  }

  if (user.role === "student") {
    req.session.userId = user.id;
    req.session.role = user.role as "student";
  }

  res.status(201).json({
    user: sanitizeUser(user),
    pendingApproval: user.role === "uploader",
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, phone, password } = parsed.data;

  let user: typeof usersTable.$inferSelect | undefined;

  if (phone) {
    const [found] = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
    user = found;
    if (!user) {
      res.status(401).json({ error: "Invalid phone number or password" });
      return;
    }
  } else {
    const [found] = await db.select().from(usersTable).where(eq(usersTable.email, email!));
    user = found;
    if (!user) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }
  }

  if (!user.passwordHash) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: phone ? "Invalid phone number or password" : "Invalid email or password" });
    return;
  }

  if (user.role === "uploader" && !user.isApproved) {
    res.status(403).json({ error: "Your uploader account is awaiting admin approval" });
    return;
  }

  req.session.userId = user.id;
  req.session.role = user.role as "admin" | "uploader" | "student";

  res.json({ user: sanitizeUser(user) });
});

router.post("/auth/logout", (req, res): void => {
  req.session.destroy(() => {
    res.clearCookie("connect.sid");
    res.json({ success: true });
  });
});

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.session.userId!));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json(sanitizeUser(user));
});

export default router;
