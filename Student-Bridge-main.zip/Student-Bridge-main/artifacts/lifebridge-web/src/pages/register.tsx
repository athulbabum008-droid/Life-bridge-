import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Building2, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

export default function Register() {
  const [, setLocation] = useLocation();
  const { register } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    role: "student" as "student" | "uploader",
    country: "",
    university: "",
  });
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const result = await register({
        email: form.email,
        phone: form.phone || undefined,
        password: form.password,
        name: form.name,
        role: form.role,
        country: form.country || undefined,
        university: form.university || undefined,
      });
      if (result.pendingApproval) {
        toast({
          title: "Account created",
          description: "Your uploader account is pending admin approval. We'll notify you once approved.",
        });
        setLocation("/login");
      } else {
        toast({ title: "Welcome to LifeBridge!", description: "Your account is ready." });
        setLocation("/");
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Registration failed";
      toast({ title: "Registration failed", description: message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-10">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
            <Building2 className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-2xl">Create your account</CardTitle>
          <CardDescription>Join the international student community in Latvia.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>I am a...</Label>
              <RadioGroup
                value={form.role}
                onValueChange={(v) => setForm({ ...form, role: v as "student" | "uploader" })}
                className="grid grid-cols-2 gap-2"
              >
                <Label
                  htmlFor="role-student"
                  className="flex cursor-pointer items-center gap-2 rounded-lg border p-3 hover:bg-muted has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                >
                  <RadioGroupItem value="student" id="role-student" />
                  <span>Student</span>
                </Label>
                <Label
                  htmlFor="role-uploader"
                  className="flex cursor-pointer items-center gap-2 rounded-lg border p-3 hover:bg-muted has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                >
                  <RadioGroupItem value="uploader" id="role-uploader" />
                  <span>Uploader</span>
                </Label>
              </RadioGroup>
              {form.role === "uploader" && (
                <p className="text-xs text-muted-foreground">
                  Uploader accounts are reviewed by an admin before activation.
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Full name</Label>
              <Input
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">
                Phone number <span className="text-muted-foreground text-xs">(optional — for phone login)</span>
              </Label>
              <Input
                id="phone"
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="+371 2000 0000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                minLength={6}
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                required
              />
            </div>
            {form.role === "student" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="country">Home country (optional)</Label>
                  <Input
                    id="country"
                    value={form.country}
                    onChange={(e) => setForm({ ...form, country: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="university">University (optional)</Label>
                  <Input
                    id="university"
                    value={form.university}
                    onChange={(e) => setForm({ ...form, university: e.target.value })}
                  />
                </div>
              </>
            )}
            <Button type="submit" className="w-full" disabled={submitting}>
              <UserPlus className="mr-2 h-4 w-4" />
              {submitting ? "Creating..." : "Create account"}
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              Already have an account?{" "}
              <Link href="/login" className="font-medium text-primary hover:underline">
                Sign in
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
