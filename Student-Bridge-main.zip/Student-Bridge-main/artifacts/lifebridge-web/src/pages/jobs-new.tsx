import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { Briefcase, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCreateListing, getGetListingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";


const schema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  price: z.coerce.number().positive("Salary must be positive").optional(),
  city: z.string().min(1, "City is required"),
  location: z.string().optional(),
  contactInfo: z.string().min(1, "Contact info is required"),
});

type FormData = z.infer<typeof schema>;

export default function JobsNew() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createListing = useCreateListing();

  const canPost = user?.role === "uploader" || user?.role === "admin";

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { title: "", description: "", city: "Riga", location: "", contactInfo: "" },
  });

  const onSubmit = (data: FormData) => {
    createListing.mutate(
      {
        data: {
          ...data,
          type: "job",
          currency: "EUR",
          images: [],
          userId: CURRENT_USER_ID,
          price: data.price ?? null,
          location: data.location ?? null,
          contactInfo: data.contactInfo ?? null,
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetListingsQueryKey() });
          toast({ title: "Job posted!", description: "Your job listing is now visible to students." });
          setLocation("/jobs");
        },
        onError: () => {
          toast({ title: "Failed to post job", variant: "destructive" });
        },
      }
    );
  };

  if (!canPost) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <button onClick={() => setLocation("/jobs")} className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors text-sm">
          <ArrowLeft className="h-4 w-4" /> Back to Jobs
        </button>
        <Card>
          <CardContent className="py-16 flex flex-col items-center gap-4 text-center">
            <Briefcase className="h-12 w-12 text-muted-foreground/30" />
            <h2 className="text-xl font-semibold">Uploaders Only</h2>
            <p className="text-muted-foreground max-w-sm">
              Only approved uploaders can post job listings. If you'd like to become an uploader, register with the uploader role and wait for admin approval.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <button onClick={() => setLocation("/jobs")} className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors text-sm">
        <ArrowLeft className="h-4 w-4" /> Back to Jobs
      </button>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-5 w-5 text-primary" />
            Post a Job Opportunity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Part-time barista, 15hrs/week" {...field} data-testid="input-job-title" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Requirements, schedule, benefits..." className="min-h-24" {...field} data-testid="input-job-desc" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Salary (EUR/month)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="600" {...field} data-testid="input-salary" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Riga">Riga</SelectItem>
                          <SelectItem value="Jurmala">Jurmala</SelectItem>
                          <SelectItem value="Liepaja">Liepaja</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="contactInfo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Info</FormLabel>
                    <FormControl>
                      <Input placeholder="Email or phone" {...field} data-testid="input-job-contact" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent text-white" disabled={createListing.isPending} data-testid="button-post-job">
                {createListing.isPending ? "Posting..." : "Post Job"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
