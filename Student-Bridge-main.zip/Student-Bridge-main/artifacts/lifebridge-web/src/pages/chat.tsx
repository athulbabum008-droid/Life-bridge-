import { useState, useEffect, useRef, useCallback } from "react";
import { MessageSquare, Send, Users, Hash, HeadphonesIcon, UserCheck, CheckCheck } from "lucide-react";
import { io, type Socket } from "socket.io-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useGetConversations,
  useGetGroups,
  useGetGroupMessages,
  useSendGroupMessage,
  useCreateConversation,
  getGetGroupMessagesQueryKey,
  getGetConversationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

type MessagePayload = {
  id: number;
  content: string;
  senderId: number;
  groupId?: number | null;
  conversationId?: number | null;
  createdAt: string;
  sender?: { id: number; name: string; role?: string } | null;
};

type MutualUser = {
  id: number;
  name: string;
  country?: string | null;
  role?: string;
};

function useGroupSocket(
  groupId: number | null,
  onMessage: (msg: MessagePayload) => void,
  onReadUpdate: (data: { groupId: number; counts: Record<number, number> }) => void
) {
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    const socket = io(window.location.origin, {
      path: "/api/socket.io",
      transports: ["websocket", "polling"],
    });
    socketRef.current = socket;

    socket.on("group-message", onMessage);
    socket.on("read-update", onReadUpdate);

    return () => {
      socket.off("group-message");
      socket.off("read-update");
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    const socket = socketRef.current;
    if (!socket) return;
    if (groupId) {
      socket.emit("join-group", groupId);
      return () => { socket.emit("leave-group", groupId); };
    }
  }, [groupId]);
}

export default function Chat() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [activeGroupId, setActiveGroupId] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [contactingAdmin, setContactingAdmin] = useState(false);
  const [liveMessages, setLiveMessages] = useState<MessagePayload[]>([]);
  const [readCounts, setReadCounts] = useState<Record<number, number>>({});
  const [mutualUsers, setMutualUsers] = useState<MutualUser[]>([]);
  const [mutualLoading, setMutualLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversations, isLoading: convsLoading } = useGetConversations({ userId: CURRENT_USER_ID });
  const { data: groups, isLoading: groupsLoading } = useGetGroups();
  const { data: groupMessages } = useGetGroupMessages(activeGroupId ?? 0, {
    query: { enabled: !!activeGroupId, queryKey: getGetGroupMessagesQueryKey(activeGroupId ?? 0) },
  });

  const sendGroupMsg = useSendGroupMessage();
  const createConversation = useCreateConversation();

  const handleReadUpdate = useCallback((data: { groupId: number; counts: Record<number, number> }) => {
    if (data.groupId === activeGroupId) {
      setReadCounts((prev) => ({ ...prev, ...data.counts }));
    }
  }, [activeGroupId]);

  useGroupSocket(activeGroupId, (msg) => {
    setLiveMessages((prev) => {
      if (prev.some((m) => m.id === msg.id)) return prev;
      return [...prev, msg];
    });
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
  }, handleReadUpdate);

  // Load mutual follows
  useEffect(() => {
    if (!CURRENT_USER_ID) return;
    setMutualLoading(true);
    fetch(`/api/follows/mutual?userId=${CURRENT_USER_ID}`, { credentials: "include" })
      .then((r) => r.json())
      .then((data: MutualUser[]) => setMutualUsers(Array.isArray(data) ? data : []))
      .catch(() => {})
      .finally(() => setMutualLoading(false));
  }, [CURRENT_USER_ID]);

  // Reset + load read counts when switching groups
  useEffect(() => {
    setLiveMessages([]);
    setReadCounts({});
    if (!activeGroupId || !CURRENT_USER_ID) return;

    // Load existing read counts
    fetch(`/api/groups/${activeGroupId}/read-counts`, { credentials: "include" })
      .then((r) => r.json())
      .then((data: Record<number, number>) => setReadCounts(data))
      .catch(() => {});

    // Mark all messages as read
    fetch(`/api/groups/${activeGroupId}/read`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: CURRENT_USER_ID }),
    })
      .then((r) => r.json())
      .then((data: { counts?: Record<number, number> }) => {
        if (data.counts) setReadCounts((prev) => ({ ...prev, ...data.counts }));
      })
      .catch(() => {});
  }, [activeGroupId, CURRENT_USER_ID]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "auto" });
  }, [groupMessages, activeGroupId]);

  const allMessages = (() => {
    if (!groupMessages) return liveMessages;
    const seen = new Set(groupMessages.map((m) => m.id));
    const extras = liveMessages.filter((m) => !seen.has(m.id));
    return [...(groupMessages as MessagePayload[]), ...extras];
  })();

  const handleSend = () => {
    if (!input.trim() || !activeGroupId || sendGroupMsg.isPending) return;

    const optimisticMsg: MessagePayload = {
      id: Date.now(),
      content: input,
      senderId: CURRENT_USER_ID,
      groupId: activeGroupId,
      createdAt: new Date().toISOString(),
      sender: user ? { id: user.id, name: user.name } : null,
    };
    setLiveMessages((prev) => [...prev, optimisticMsg]);
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });

    const sentContent = input;
    setInput("");

    sendGroupMsg.mutate(
      { id: activeGroupId, data: { senderId: CURRENT_USER_ID, content: sentContent } },
      {
        onSuccess: (serverMsg) => {
          setLiveMessages((prev) =>
            prev.map((m) => (m.id === optimisticMsg.id ? (serverMsg as MessagePayload) : m))
          );
          queryClient.invalidateQueries({ queryKey: getGetGroupMessagesQueryKey(activeGroupId) });
        },
        onError: () => {
          setLiveMessages((prev) => prev.filter((m) => m.id !== optimisticMsg.id));
          toast({ title: "Failed to send message", variant: "destructive" });
          setInput(sentContent);
        },
      }
    );
  };

  const handleContactAdmin = async () => {
    if (!CURRENT_USER_ID || contactingAdmin) return;
    setContactingAdmin(true);
    try {
      const res = await fetch("/api/admin-contact", { credentials: "include" });
      if (!res.ok) throw new Error("Could not find admin");
      const { adminId } = (await res.json()) as { adminId: number };

      await createConversation.mutateAsync({
        data: { participant1Id: CURRENT_USER_ID, participant2Id: adminId },
      });
      queryClient.invalidateQueries({ queryKey: getGetConversationsQueryKey({ userId: CURRENT_USER_ID }) });
      toast({ title: "Support conversation started", description: "The admin will get back to you shortly." });
    } catch {
      toast({ title: "Could not reach admin", variant: "destructive" });
    } finally {
      setContactingAdmin(false);
    }
  };

  const handleMessageMutual = async (targetId: number) => {
    if (!CURRENT_USER_ID) return;
    try {
      await createConversation.mutateAsync({
        data: { participant1Id: CURRENT_USER_ID, participant2Id: targetId },
      });
      queryClient.invalidateQueries({ queryKey: getGetConversationsQueryKey({ userId: CURRENT_USER_ID }) });
      toast({ title: "Conversation started!" });
    } catch {
      toast({ title: "Could not start conversation", variant: "destructive" });
    }
  };

  const activeGroup = groups?.find((g) => g.id === activeGroupId);

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold gradient-text">Messages</h1>
        {user?.role !== "admin" && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleContactAdmin}
            disabled={contactingAdmin}
            className="flex items-center gap-2 border-border/50 hover:border-primary/40 hover:text-primary"
          >
            <HeadphonesIcon className="h-4 w-4" />
            {contactingAdmin ? "Connecting..." : "Contact Support"}
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <Tabs defaultValue="groups">
            <TabsList className="w-full mb-4 bg-muted/50 border border-border/50">
              <TabsTrigger value="groups" className="flex-1 data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Groups</TabsTrigger>
              <TabsTrigger value="direct" className="flex-1 data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
                Direct
                {mutualUsers.length > 0 && (
                  <span className="ml-1.5 bg-primary text-white text-xs rounded-full w-4 h-4 inline-flex items-center justify-center">
                    {mutualUsers.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="groups">
              {groupsLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
                </div>
              ) : (
                <div className="space-y-1">
                  {groups?.map((group) => (
                    <button
                      key={group.id}
                      onClick={() => setActiveGroupId(group.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${
                        activeGroupId === group.id
                          ? "bg-primary/10 text-primary border border-primary/20 electric-border"
                          : "hover:bg-muted/60 border border-transparent"
                      }`}
                    >
                      <div className={`p-2 rounded-lg ${activeGroupId === group.id ? "bg-primary/20" : "bg-muted/80"}`}>
                        <Hash className={`h-4 w-4 ${activeGroupId === group.id ? "text-primary" : "text-muted-foreground"}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{group.name}</p>
                        <p className="text-xs text-muted-foreground">{group.memberCount.toLocaleString()} members</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="direct">
              {/* Mutual followers you can DM */}
              {mutualLoading ? (
                <div className="space-y-2 mb-3">
                  {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
                </div>
              ) : mutualUsers.length > 0 ? (
                <div className="mb-4">
                  <p className="text-xs text-muted-foreground font-medium px-1 mb-2 flex items-center gap-1.5">
                    <UserCheck className="h-3.5 w-3.5 text-primary" /> Mutual Follows
                  </p>
                  <div className="space-y-1">
                    {mutualUsers.map((mu) => (
                      <button
                        key={mu.id}
                        onClick={() => handleMessageMutual(mu.id)}
                        className="w-full flex items-center gap-3 p-3 rounded-xl text-left hover:bg-muted/60 border border-transparent hover:border-primary/20 transition-all"
                      >
                        <Avatar className="h-9 w-9 ring-1 ring-primary/30">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                            {mu.name.split(" ").map((n) => n[0]).join("").substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{mu.name}</p>
                          <p className="text-xs text-primary/70">Tap to message</p>
                        </div>
                      </button>
                    ))}
                  </div>
                  <div className="border-t border-border/40 mt-3 mb-3" />
                </div>
              ) : null}

              {/* Existing conversations */}
              {convsLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
                </div>
              ) : conversations && conversations.length > 0 ? (
                <div className="space-y-1">
                  {conversations.map((conv) => {
                    const other =
                      conv.participant1Id === CURRENT_USER_ID ? conv.participant2 : conv.participant1;
                    const isSupport = (other as { role?: string } | null)?.role === "admin";
                    return (
                      <button
                        key={conv.id}
                        className="w-full flex items-center gap-3 p-3 rounded-xl text-left hover:bg-muted/60 border border-transparent hover:border-primary/20 transition-all"
                      >
                        <Avatar className="h-9 w-9">
                          <AvatarFallback
                            className={`${isSupport ? "bg-primary text-white" : "bg-primary/10 text-primary"} text-xs font-semibold`}
                          >
                            {isSupport
                              ? "S"
                              : ((other as { name?: string } | null)?.name
                                  ?.split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .substring(0, 2) ?? "?")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="font-medium text-sm truncate">
                              {isSupport ? "LifeBridge Support" : ((other as { name?: string } | null)?.name ?? "Unknown")}
                            </p>
                            {isSupport && (
                              <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">Support</Badge>
                            )}
                          </div>
                          {conv.lastMessage && (
                            <p className="text-xs text-muted-foreground truncate">{conv.lastMessage}</p>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center py-8 gap-3">
                  <MessageSquare className="h-8 w-8 text-muted-foreground/30" />
                  <p className="text-xs text-muted-foreground text-center">
                    {mutualUsers.length === 0
                      ? "Follow students on Community and wait for them to follow back to unlock DMs."
                      : "No conversations yet. Tap a mutual follow above to start one."}
                  </p>
                  {user?.role !== "admin" && (
                    <Button size="sm" variant="outline" onClick={handleContactAdmin} disabled={contactingAdmin}
                      className="border-border/50 hover:border-primary/40 hover:text-primary">
                      <HeadphonesIcon className="mr-1.5 h-3.5 w-3.5" />
                      Message Support
                    </Button>
                  )}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Chat Window */}
        <div className="lg:col-span-2">
          {activeGroup ? (
            <div className="flex flex-col h-[calc(100vh-250px)] min-h-[400px] border border-border/50 rounded-2xl overflow-hidden bg-card/50">
              {/* Header */}
              <div className="flex items-center gap-3 p-4 border-b border-border/50 bg-card/80 backdrop-blur-sm">
                <div className="p-2 bg-primary/15 rounded-lg ring-1 ring-primary/30">
                  <Hash className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="font-semibold">{activeGroup.name}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Users className="h-3 w-3" /> {activeGroup.memberCount.toLocaleString()} members ·{" "}
                    <span className="inline-flex items-center gap-0.5 text-primary">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                      Live
                    </span>
                  </p>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {allMessages.length > 0 ? (
                  allMessages.map((msg, idx) => {
                    const isMe = msg.senderId === CURRENT_USER_ID;
                    const isLast = idx === allMessages.length - 1;
                    const readCount = readCounts[msg.id] ?? 0;
                    return (
                      <div key={msg.id} className={`flex gap-2 ${isMe ? "flex-row-reverse" : ""}`}>
                        {!isMe && (
                          <Avatar className="h-7 w-7 flex-shrink-0 mt-1">
                            <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                              {msg.sender?.name
                                ?.split(" ")
                                .map((n) => n[0])
                                .join("")
                                .substring(0, 2) ?? "?"}
                            </AvatarFallback>
                          </Avatar>
                        )}
                        <div className={`max-w-[75%] ${isMe ? "items-end" : "items-start"} flex flex-col gap-0.5`}>
                          {!isMe && (
                            <span className="text-xs text-muted-foreground ml-1">{msg.sender?.name}</span>
                          )}
                          <div
                            className={`px-4 py-2.5 rounded-2xl text-sm ${
                              isMe
                                ? "bg-primary text-white rounded-br-sm shadow-[0_0_12px_hsl(210_100%_52%/0.3)]"
                                : "bg-muted/80 rounded-bl-sm border border-border/40"
                            }`}
                          >
                            {msg.content}
                          </div>
                          {/* Read receipts — show on last message from me */}
                          {isMe && isLast && readCount > 0 && (
                            <div className="flex items-center gap-1 text-[10px] text-primary/60 mr-1">
                              <CheckCheck className="h-3 w-3 text-primary" />
                              Seen by {readCount}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="flex flex-col items-center py-10 gap-2">
                    <MessageSquare className="h-8 w-8 text-muted-foreground/20" />
                    <p className="text-sm text-muted-foreground">No messages yet. Start the conversation!</p>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-3 border-t border-border/50 bg-card/80 flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
                  placeholder={`Message #${activeGroup.name}...`}
                  className="flex-1 bg-muted/50 border-border/50 focus:border-primary/50 focus:ring-primary/20"
                />
                <Button
                  onClick={handleSend}
                  disabled={sendGroupMsg.isPending || !input.trim()}
                  size="icon"
                  className="bg-primary hover:bg-primary/90 text-white flex-shrink-0 glow-blue"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-[400px] border-2 border-dashed border-border/40 rounded-2xl gap-3 bg-card/20">
              <div className="p-4 rounded-2xl bg-primary/5 ring-1 ring-primary/20">
                <MessageSquare className="h-10 w-10 text-primary/40" />
              </div>
              <p className="text-muted-foreground font-medium">Select a group to start chatting</p>
              <p className="text-xs text-muted-foreground/60 text-center max-w-[200px]">
                Or go to Community to follow students and unlock private DMs
              </p>
              {user?.role !== "admin" && (
                <Button variant="outline" size="sm" onClick={handleContactAdmin} disabled={contactingAdmin}
                  className="border-border/50 hover:border-primary/40 hover:text-primary">
                  <HeadphonesIcon className="mr-1.5 h-4 w-4" />
                  Or contact support
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
