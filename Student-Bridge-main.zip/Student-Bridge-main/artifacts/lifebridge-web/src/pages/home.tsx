import { Link } from "wouter";
import { Building2, Briefcase, BookOpen, ArrowRight, Users, MapPin, TrendingUp, CheckCircle, Home as HomeIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useGetListingStats, useGetRecentListings, useGetScenarios, useGetChecklist } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";


export default function Home() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const { data: stats, isLoading: statsLoading } = useGetListingStats();
  const { data: recent, isLoading: recentLoading } = useGetRecentListings({ limit: 4 });
  const { data: scenarios } = useGetScenarios();
  const { data: checklist } = useGetChecklist({ userId: CURRENT_USER_ID });

  const completedItems = checklist?.filter((i) => i.isCompleted).length ?? 0;
  const totalItems = checklist?.length ?? 10;
  const progressPercent = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-accent/5 to-background py-16 md:py-24">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-2xl">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
              Your life in Latvia starts here
            </Badge>
            <h1 className="text-4xl md:text-6xl font-extrabold text-foreground leading-tight mb-4">
              Find home,{" "}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                work & fit in
              </span>
            </h1>
            <p className="text-muted-foreground text-lg mb-8 max-w-xl">
              LifeBridge connects international students with real housing, student jobs, AI practice scenarios, and a welcoming community in Latvia.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/housing">
                <Button size="lg" className="bg-gradient-to-r from-primary to-accent text-white shadow-lg hover:shadow-primary/25 hover:scale-105 transition-all">
                  <Building2 className="mr-2 h-5 w-5" />
                  Browse Housing
                </Button>
              </Link>
              <Link href="/simulate">
                <Button size="lg" variant="outline" className="border-primary/30 hover:bg-primary/5">
                  <BookOpen className="mr-2 h-5 w-5" />
                  Practice Scenarios
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-10 border-b bg-card/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {statsLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-20 rounded-xl" />
              ))
            ) : (
              <>
                <StatCard icon={<Building2 className="text-primary" />} value={String(stats?.totalApartments ?? 0)} label="Apartments" />
                <StatCard icon={<Briefcase className="text-accent" />} value={String(stats?.totalJobs ?? 0)} label="Job Posts" />
                <StatCard icon={<MapPin className="text-green-500" />} value={`${stats?.avgApartmentPrice ?? 0} EUR`} label="Avg. Rent" />
                <StatCard icon={<TrendingUp className="text-orange-500" />} value={String(stats?.recentActivity ?? 0)} label="This Week" />
              </>
            )}
          </div>
        </div>
      </section>

      {/* Recent Listings */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Recent Listings</h2>
            <Link href="/housing">
              <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                View all <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {recentLoading
              ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)
              : recent?.slice(0, 4).map((listing) => (
                  <Card key={listing.id} className="group hover:shadow-lg transition-all duration-200 hover:-translate-y-1 overflow-hidden cursor-pointer">
                    <div className="h-28 bg-gradient-to-br from-primary/15 to-accent/10 flex items-center justify-center">
                      {listing.type === "apartment" ? (
                        <HomeIcon className="h-10 w-10 text-primary/40" />
                      ) : (
                        <Briefcase className="h-10 w-10 text-accent/40" />
                      )}
                    </div>
                    <CardContent className="p-4">
                      <Badge variant="outline" className="text-xs mb-1">
                        {listing.type === "apartment" ? "Housing" : "Job"}
                      </Badge>
                      <p className="font-semibold text-sm line-clamp-2 mb-1 group-hover:text-primary transition-colors">{listing.title}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" /> {listing.city}
                        </span>
                        {listing.price && (
                          <span className="text-sm font-bold text-primary">{listing.price} EUR</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-6">Get Started</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            <QuickActionCard
              to="/simulate"
              icon={<BookOpen className="h-6 w-6 text-primary" />}
              title="Practice Real Situations"
              description="AI-powered simulations for renting, job interviews, and doctor visits."
              badge="AI Powered"
              badgeColor="bg-purple-100 text-purple-700"
              scenarios={scenarios?.slice(0, 3)}
            />
            <QuickActionCard
              to="/cultural"
              icon={<MapPin className="h-6 w-6 text-green-600" />}
              title="Cultural Guide"
              description="Understand Latvian customs, bureaucracy, and visa rules."
              badge="Latvia Tips"
              badgeColor="bg-green-100 text-green-700"
            />
            <QuickActionCard
              to="/community"
              icon={<Users className="h-6 w-6 text-orange-500" />}
              title="Find Your Community"
              description="Connect with students from your country and university."
              badge="Community"
              badgeColor="bg-orange-100 text-orange-700"
            />
          </div>
        </div>
      </section>

      {/* Checklist Preview */}
      {checklist && checklist.length > 0 && (
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/10 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold">Your Arrival Checklist</h3>
                  <p className="text-muted-foreground text-sm">{completedItems} of {totalItems} tasks completed</p>
                </div>
                <Link href="/cultural">
                  <Button variant="outline" size="sm" className="border-primary/20 hover:bg-primary/5">
                    View all <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </div>
              <div className="w-full bg-muted rounded-full h-2 mb-4">
                <div
                  className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {checklist.slice(0, 4).map((item) => (
                  <div key={item.id} className="flex items-center gap-2 text-sm">
                    <CheckCircle
                      className={`h-4 w-4 flex-shrink-0 ${item.isCompleted ? "text-green-500" : "text-muted-foreground/30"}`}
                    />
                    <span className={item.isCompleted ? "line-through text-muted-foreground" : ""}>{item.title}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

function StatCard({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="flex items-center gap-3 p-4 rounded-xl bg-card border">
      <div className="p-2 rounded-lg bg-muted/50">{icon}</div>
      <div>
        <p className="text-2xl font-bold">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

function QuickActionCard({
  to,
  icon,
  title,
  description,
  badge,
  badgeColor,
  scenarios,
}: {
  to: string;
  icon: React.ReactNode;
  title: string;
  description: string;
  badge: string;
  badgeColor: string;
  scenarios?: any[];
}) {
  return (
    <Link href={to}>
      <Card className="h-full hover:shadow-lg transition-all duration-200 hover:-translate-y-1 cursor-pointer group">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="p-3 rounded-xl bg-muted/50 group-hover:scale-110 transition-transform">{icon}</div>
            <span className={`text-xs font-medium px-2 py-1 rounded-full ${badgeColor}`}>{badge}</span>
          </div>
          <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{title}</h3>
          <p className="text-muted-foreground text-sm">{description}</p>
          {scenarios && (
            <div className="mt-3 flex flex-wrap gap-1">
              {scenarios.map((s) => (
                <span key={s.id} className="text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                  {s.title}
                </span>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
