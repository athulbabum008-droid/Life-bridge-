import { useState } from "react";
import { BookOpen, Send, Star, MessageSquare, ChevronRight, ArrowLeft, BarChart2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useGetScenarios,
  useGetScenarioProgress,
  useChatWithScenario,
  useSaveScenarioProgress,
} from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";


interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface Feedback {
  tone: string;
  language: string;
  suggestion: string;
  score: number;
}

const DIFFICULTY_COLORS: Record<string, string> = {
  beginner: "bg-green-100 text-green-700",
  intermediate: "bg-yellow-100 text-yellow-700",
  advanced: "bg-red-100 text-red-700",
};

export default function Simulate() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const { data: scenarios, isLoading } = useGetScenarios();
  const { data: progress } = useGetScenarioProgress({ userId: CURRENT_USER_ID });
  const chatMutation = useChatWithScenario();
  const saveProgress = useSaveScenarioProgress();

  const [activeScenarioId, setActiveScenarioId] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [lastFeedback, setLastFeedback] = useState<Feedback | null>(null);
  const [messageCount, setMessageCount] = useState(0);

  const activeScenario = scenarios?.find((s) => s.id === activeScenarioId);
  const completedIds = new Set(
    progress?.filter((p) => p.completedAt).map((p) => p.scenarioId) ?? []
  );

  const startScenario = (id: number) => {
    setActiveScenarioId(id);
    setMessages([
      {
        role: "assistant",
        content: "Hello! I'm ready to begin our practice session. How can I help you today?",
      },
    ]);
    setLastFeedback(null);
    setMessageCount(0);
  };

  const sendMessage = () => {
    if (!input.trim() || !activeScenarioId || chatMutation.isPending) return;

    const userMsg: ChatMessage = { role: "user", content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    const newCount = messageCount + 1;
    setMessageCount(newCount);

    chatMutation.mutate(
      {
        id: activeScenarioId,
        data: {
          message: input,
          history: messages.map((m) => ({ role: m.role, content: m.content })),
        },
      },
      {
        onSuccess: (data) => {
          setMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
          setLastFeedback(data.feedback);

          // Save progress
          saveProgress.mutate({
            data: {
              userId: CURRENT_USER_ID,
              scenarioId: activeScenarioId,
              totalMessages: newCount,
              lastScore: data.feedback.score,
              completedAt: newCount >= 5 ? new Date().toISOString() : null,
            },
          });
        },
      }
    );
  };

  if (activeScenario) {
    return (
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <button
          onClick={() => setActiveScenarioId(null)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4 text-sm transition-colors"
        >
          <ArrowLeft className="h-4 w-4" /> Back to scenarios
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat */}
          <div className="lg:col-span-2 flex flex-col">
            <div className="bg-gradient-to-r from-primary/10 to-accent/5 rounded-t-2xl p-4 border-b border-primary/10">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/80 rounded-xl shadow-sm">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">{activeScenario.title}</h2>
                  <Badge className={`text-xs ${DIFFICULTY_COLORS[activeScenario.difficulty]}`}>
                    {activeScenario.difficulty}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="flex-1 min-h-80 max-h-[50vh] overflow-y-auto p-4 space-y-3 bg-card border-x">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${i}`}
                >
                  <div
                    className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm ${
                      msg.role === "user"
                        ? "bg-gradient-to-r from-primary to-accent text-white rounded-br-sm"
                        : "bg-muted text-foreground rounded-bl-sm"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {chatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="bg-muted px-4 py-3 rounded-2xl rounded-bl-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="border-x border-b rounded-b-2xl bg-card p-3 flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                placeholder="Type your response..."
                data-testid="input-chat"
                className="flex-1"
              />
              <Button
                onClick={sendMessage}
                disabled={chatMutation.isPending || !input.trim()}
                size="icon"
                className="bg-gradient-to-r from-primary to-accent text-white"
                data-testid="button-send"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Feedback Panel */}
          <div className="space-y-4">
            {lastFeedback ? (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <BarChart2 className="h-4 w-4 text-primary" />
                    AI Feedback
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">Score</span>
                      <span className="text-2xl font-bold text-primary">{lastFeedback.score}/10</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all"
                        style={{ width: `${lastFeedback.score * 10}%` }}
                      />
                    </div>
                  </div>
                  <div className="space-y-3 text-sm">
                    <FeedbackItem label="Tone" value={lastFeedback.tone} />
                    <FeedbackItem label="Language" value={lastFeedback.language} />
                    <div className="bg-primary/5 border border-primary/10 rounded-xl p-3">
                      <p className="text-xs text-muted-foreground font-medium mb-1">Suggestion</p>
                      <p className="text-sm">{lastFeedback.suggestion}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="opacity-60">
                <CardContent className="p-6 text-center">
                  <Star className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Send a message to get AI feedback on your response</p>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Messages sent</span>
                  <span className="font-bold text-primary">{messageCount}</span>
                </div>
                {messageCount >= 5 && (
                  <div className="mt-2 text-xs text-green-600 font-medium">
                    Scenario completed!
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Practice Scenarios</h1>
        <p className="text-muted-foreground">
          AI-powered simulations of real-life situations you'll face as an international student in Latvia.
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
        </div>
      ) : scenarios && scenarios.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {scenarios.map((scenario) => {
            const isCompleted = completedIds.has(scenario.id);
            const prog = progress?.find((p) => p.scenarioId === scenario.id);
            return (
              <Card
                key={scenario.id}
                data-testid={`card-scenario-${scenario.id}`}
                className="group hover:shadow-lg transition-all duration-200 hover:-translate-y-1 cursor-pointer relative overflow-hidden"
                onClick={() => startScenario(scenario.id)}
              >
                {isCompleted && (
                  <div className="absolute top-3 right-3 bg-green-500 text-white rounded-full p-1">
                    <Star className="h-3 w-3" />
                  </div>
                )}
                <CardContent className="p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="p-3 rounded-xl bg-primary/10 group-hover:bg-primary/15 transition-colors">
                      <MessageSquare className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <Badge className={`text-xs mb-1 ${DIFFICULTY_COLORS[scenario.difficulty] ?? "bg-gray-100 text-gray-700"}`}>
                        {scenario.difficulty}
                      </Badge>
                      <Badge variant="outline" className="text-xs ml-1">{scenario.category}</Badge>
                    </div>
                  </div>
                  <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">{scenario.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{scenario.description}</p>
                  <div className="flex items-center justify-between">
                    {prog && (
                      <span className="text-xs text-muted-foreground">{prog.totalMessages} messages • Score: {prog.lastScore ?? "—"}/10</span>
                    )}
                    <Button size="sm" variant="ghost" className="ml-auto text-primary hover:text-primary group-hover:translate-x-1 transition-transform">
                      Start <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center py-16 gap-3">
          <BookOpen className="h-12 w-12 text-muted-foreground/30" />
          <p className="text-muted-foreground">No scenarios available yet</p>
        </div>
      )}
    </div>
  );
}

function FeedbackItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span className="text-xs text-muted-foreground">{label}: </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
