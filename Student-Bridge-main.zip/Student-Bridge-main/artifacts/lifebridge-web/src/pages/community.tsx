import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Users, MessageSquare, MapPin, ArrowRight, UserPlus, UserCheck, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetMatchedUsers, useGetGroups } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

const CATEGORY_COLORS: Record<string, string> = {
  Housing: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  Jobs: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  General: "bg-violet-500/10 text-violet-400 border-violet-500/20",
  University: "bg-orange-500/10 text-orange-400 border-orange-500/20",
};

type PublicUser = {
  id: number;
  name: string;
  country?: string | null;
  university?: string | null;
  isVerified?: boolean;
};

function FollowButton({ targetId, currentUserId }: { targetId: number; currentUserId: number }) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (!currentUserId || !targetId) { setLoading(false); return; }
    fetch(`/api/follows/check?followerId=${currentUserId}&followingId=${targetId}`, { credentials: "include" })
      .then((r) => r.json())
      .then((data: { isFollowing: boolean }) => setIsFollowing(data.isFollowing))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [currentUserId, targetId]);

  const toggle = async () => {
    setLoading(true);
    try {
      if (isFollowing) {
        await fetch("/api/follows", {
          method: "DELETE",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ followerId: currentUserId, followingId: targetId }),
        });
        setIsFollowing(false);
        toast({ title: "Unfollowed" });
      } else {
        await fetch("/api/follows", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ followerId: currentUserId, followingId: targetId }),
        });
        setIsFollowing(true);
        toast({ title: "Following!", description: "You can now DM each other once they follow back." });
      }
    } catch {
      toast({ title: "Error", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      size="sm"
      variant={isFollowing ? "secondary" : "default"}
      className={`w-full text-xs mt-1 ${
        isFollowing
          ? "bg-primary/10 text-primary border border-primary/30 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30"
          : "bg-primary text-white hover:bg-primary/90 glow-blue"
      }`}
      onClick={toggle}
      disabled={loading}
    >
      {loading ? (
        <Loader2 className="h-3 w-3 animate-spin" />
      ) : isFollowing ? (
        <><UserCheck className="mr-1 h-3 w-3" /> Following</>
      ) : (
        <><UserPlus className="mr-1 h-3 w-3" /> Follow</>
      )}
    </Button>
  );
}

export default function Community() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const { data: matchedUsers, isLoading: usersLoading } = useGetMatchedUsers({ userId: CURRENT_USER_ID, limit: 8 });
  const { data: groups, isLoading: groupsLoading } = useGetGroups();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 gradient-text">Community</h1>
        <p className="text-muted-foreground">Connect with fellow international students in Latvia</p>
      </div>

      {/* Matched Users */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Students Like You
          </h2>
          <p className="text-xs text-muted-foreground">Follow each other to unlock private DMs</p>
        </div>

        {usersLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
          </div>
        ) : matchedUsers && matchedUsers.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(matchedUsers as PublicUser[]).map((u) => (
              <Card
                key={u.id}
                data-testid={`card-user-${u.id}`}
                className="card-hover border-border/50 bg-card/80 backdrop-blur-sm"
              >
                <CardContent className="p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar className="h-10 w-10 ring-2 ring-primary/20">
                      <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
                        {u.name.split(" ").map((n) => n[0]).join("").substring(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{u.name}</p>
                      {u.country && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" /> {u.country}
                        </p>
                      )}
                    </div>
                    {u.isVerified && (
                      <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 glow-blue" title="Verified" />
                    )}
                  </div>
                  {u.university && (
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-1">{u.university}</p>
                  )}
                  {CURRENT_USER_ID && CURRENT_USER_ID !== u.id ? (
                    <FollowButton targetId={u.id} currentUserId={CURRENT_USER_ID} />
                  ) : (
                    <Link href="/chat">
                      <Button size="sm" variant="outline" className="w-full text-xs">
                        <MessageSquare className="mr-1 h-3 w-3" /> Message
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center py-10 gap-3">
            <Users className="h-10 w-10 text-muted-foreground/30" />
            <p className="text-muted-foreground text-sm">No matched students found</p>
          </div>
        )}
      </section>

      {/* Group Chats */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-accent" />
            Group Chats
          </h2>
          <Link href="/chat">
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
              Open messages <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>

        {groupsLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
          </div>
        ) : groups && groups.length > 0 ? (
          <div className="space-y-3">
            {groups.map((group) => (
              <Card key={group.id} data-testid={`card-group-${group.id}`} className="card-hover border-border/50 bg-card/80 cursor-pointer">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
                        <MessageSquare className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-0.5">
                          <p className="font-semibold">{group.name}</p>
                          <Badge className={`text-xs border ${CATEGORY_COLORS[group.category] ?? "bg-muted text-muted-foreground border-border"}`}>
                            {group.category}
                          </Badge>
                        </div>
                        {group.description && (
                          <p className="text-sm text-muted-foreground line-clamp-1">{group.description}</p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          <Users className="inline h-3 w-3 mr-1" />
                          {group.memberCount.toLocaleString()} members
                        </p>
                      </div>
                    </div>
                    <Link href="/chat">
                      <Button size="sm" className="bg-primary text-white hover:bg-primary/90 glow-blue">
                        Join <ArrowRight className="ml-1 h-3 w-3" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center py-10 gap-3">
            <MessageSquare className="h-10 w-10 text-muted-foreground/30" />
            <p className="text-muted-foreground text-sm">No groups available</p>
          </div>
        )}
      </section>
    </div>
  );
}
