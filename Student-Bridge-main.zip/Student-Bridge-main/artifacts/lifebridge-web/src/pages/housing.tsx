import { useState } from "react";
import { Link } from "wouter";
import { Building2, MapPin, Plus, Filter, ExternalLink, Bookmark, BookmarkCheck, Flag, Home as HomeIcon, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useGetListings,
  useGetSslvApartments,
  useAddBookmark,
  useGetBookmarks,
  useRemoveBookmark,
  getGetBookmarksQueryKey,
  useReportListing,
  getGetListingsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";


export default function Housing() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [city, setCity] = useState("");
  const [maxPrice, setMaxPrice] = useState<number | undefined>();
  const [searchInput, setSearchInput] = useState("");

  const { data: userListings, isLoading: userLoading } = useGetListings({
    type: "apartment",
    city: city || undefined,
  });

  const { data: sslvListings, isLoading: sslvLoading } = useGetSslvApartments({
    city: city || "riga",
    maxPrice,
  });

  const { data: bookmarks } = useGetBookmarks({ userId: CURRENT_USER_ID });
  const addBookmark = useAddBookmark();
  const removeBookmark = useRemoveBookmark();
  const reportListing = useReportListing();

  const bookmarkedIds = new Set(bookmarks?.map((b) => b.listingId) ?? []);

  const handleBookmark = (listingId: number) => {
    const existingBookmark = bookmarks?.find((b) => b.listingId === listingId);
    if (existingBookmark) {
      removeBookmark.mutate(
        { id: existingBookmark.id },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getGetBookmarksQueryKey({ userId: CURRENT_USER_ID }) });
            toast({ title: "Removed from bookmarks" });
          },
        }
      );
    } else {
      addBookmark.mutate(
        { data: { userId: CURRENT_USER_ID, listingId } },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getGetBookmarksQueryKey({ userId: CURRENT_USER_ID }) });
            toast({ title: "Saved to bookmarks" });
          },
        }
      );
    }
  };

  const handleReport = (listingId: number) => {
    reportListing.mutate(
      { id: listingId, data: { reason: "Inappropriate or fake listing" } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetListingsQueryKey() });
          toast({ title: "Listing reported", description: "Thank you for keeping the community safe." });
        },
      }
    );
  };

  const filteredUserListings = userListings?.listings?.filter((l) =>
    !searchInput || l.title.toLowerCase().includes(searchInput.toLowerCase())
  );

  const filteredSslvListings = sslvListings?.filter((l) =>
    !searchInput || l.title.toLowerCase().includes(searchInput.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Find Housing</h1>
          <p className="text-muted-foreground mt-1">Apartments from SS.lv and fellow students</p>
        </div>
        {(user?.role === "uploader" || user?.role === "admin") && (
          <Link href="/housing/new">
            <Button className="bg-gradient-to-r from-primary to-accent text-white">
              <Plus className="mr-2 h-4 w-4" /> Post Listing
            </Button>
          </Link>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6 bg-card border rounded-xl p-4">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search listings..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9"
            data-testid="input-search"
          />
        </div>
        <Select value={city || "all"} onValueChange={(v) => setCity(v === "all" ? "" : v)}>
          <SelectTrigger className="w-40" data-testid="select-city">
            <SelectValue placeholder="City" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All cities</SelectItem>
            <SelectItem value="Riga">Riga</SelectItem>
            <SelectItem value="Jurmala">Jurmala</SelectItem>
            <SelectItem value="Liepaja">Liepaja</SelectItem>
            <SelectItem value="Ventspils">Ventspils</SelectItem>
          </SelectContent>
        </Select>
        <Select value={maxPrice ? String(maxPrice) : "any"} onValueChange={(v) => setMaxPrice(v === "any" ? undefined : Number(v))}>
          <SelectTrigger className="w-44" data-testid="select-max-price">
            <SelectValue placeholder="Max price" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any price</SelectItem>
            <SelectItem value="300">Up to 300 EUR</SelectItem>
            <SelectItem value="500">Up to 500 EUR</SelectItem>
            <SelectItem value="700">Up to 700 EUR</SelectItem>
            <SelectItem value="1000">Up to 1000 EUR</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="sslv">
        <TabsList className="mb-6">
          <TabsTrigger value="sslv" data-testid="tab-sslv">
            SS.lv Listings
            <Badge variant="secondary" className="ml-2 text-xs">{sslvListings?.length ?? 0}</Badge>
          </TabsTrigger>
          <TabsTrigger value="user" data-testid="tab-user">
            Student Listings
            <Badge variant="secondary" className="ml-2 text-xs">{filteredUserListings?.length ?? 0}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sslv">
          {sslvLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
            </div>
          ) : filteredSslvListings && filteredSslvListings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredSslvListings.map((listing) => (
                <Card key={listing.id} className="group hover:shadow-md transition-all duration-200 hover:-translate-y-0.5 overflow-hidden">
                  <div className="h-32 bg-gradient-to-br from-primary/10 to-accent/5 flex items-center justify-center relative">
                    <HomeIcon className="h-12 w-12 text-primary/25" />
                    <Badge className="absolute top-2 left-2 bg-orange-500/90 text-white text-xs">SS.lv</Badge>
                  </div>
                  <CardContent className="p-4">
                    <p className="font-semibold text-sm line-clamp-2 mb-2 group-hover:text-primary transition-colors">
                      {listing.title}
                    </p>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {listing.location}
                      </span>
                      {listing.price && (
                        <span className="text-sm font-bold text-primary">{listing.price}</span>
                      )}
                    </div>
                    <a
                      href={listing.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full"
                      data-testid={`link-sslv-${listing.id}`}
                    >
                      <Button size="sm" variant="outline" className="w-full text-xs hover:bg-primary/5">
                        <ExternalLink className="mr-1 h-3 w-3" /> View on SS.lv
                      </Button>
                    </a>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <EmptyState icon={<Building2 className="h-12 w-12 text-muted-foreground/30" />} text="No SS.lv listings found" />
          )}
        </TabsContent>

        <TabsContent value="user">
          {userLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
            </div>
          ) : filteredUserListings && filteredUserListings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredUserListings.map((listing) => (
                <Card key={listing.id} data-testid={`card-listing-${listing.id}`} className="group hover:shadow-md transition-all duration-200 hover:-translate-y-0.5 overflow-hidden">
                  <div className="h-32 bg-gradient-to-br from-primary/10 to-accent/5 flex items-center justify-center relative">
                    <HomeIcon className="h-12 w-12 text-primary/25" />
                    <Badge className="absolute top-2 left-2 bg-primary/90 text-white text-xs">Student Post</Badge>
                  </div>
                  <CardContent className="p-4">
                    <p className="font-semibold text-sm line-clamp-2 mb-1 group-hover:text-primary transition-colors">
                      {listing.title}
                    </p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{listing.description}</p>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {listing.city}
                      </span>
                      {listing.price && (
                        <span className="text-sm font-bold text-primary">{listing.price} EUR</span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant={bookmarkedIds.has(listing.id) ? "default" : "outline"}
                        className="flex-1 text-xs"
                        onClick={() => handleBookmark(listing.id)}
                        data-testid={`button-bookmark-${listing.id}`}
                      >
                        {bookmarkedIds.has(listing.id) ? (
                          <><BookmarkCheck className="mr-1 h-3 w-3" /> Saved</>
                        ) : (
                          <><Bookmark className="mr-1 h-3 w-3" /> Save</>
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-xs text-muted-foreground hover:text-destructive"
                        onClick={() => handleReport(listing.id)}
                        data-testid={`button-report-${listing.id}`}
                      >
                        <Flag className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <EmptyState icon={<Building2 className="h-12 w-12 text-muted-foreground/30" />} text="No student listings yet. Be the first to post!" />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function EmptyState({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
      {icon}
      <p className="text-muted-foreground">{text}</p>
    </div>
  );
}
