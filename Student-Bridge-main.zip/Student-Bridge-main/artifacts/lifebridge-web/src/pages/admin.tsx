import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import {
  Users as UsersIcon,
  ShieldCheck,
  Building2,
  Briefcase,
  CheckCircle2,
  XCircle,
  Trash2,
  Clock,
  BookOpen,
  Plus,
  Edit2,
  MessageSquare,
  Hash,
  Activity,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  useGetAdminStats,
  useGetAllUsers,
  useGetAdminListings,
  useApproveUser,
  useUpdateUserRole,
  useDeleteUser,
  useApproveListing,
  useAdminDeleteListing,
  useUpdateListing,
  useGetCulturalTips,
  useCreateCulturalTip,
  useUpdateCulturalTip,
  useDeleteCulturalTip,
  getGetAdminStatsQueryKey,
  getGetAllUsersQueryKey,
  getGetAdminListingsQueryKey,
  getGetCulturalTipsQueryKey,
} from "@workspace/api-client-react";
import type { CulturalTip, Listing, PublicUser } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

// ─── Types for raw-fetch endpoints ───────────────────────────────────────────
type AdminOverview = {
  recentUsers: PublicUser[];
  recentListings: Listing[];
  recentMessages: { id: number; content: string; senderName: string; groupName: string | null; createdAt: string; groupId?: number | null; conversationId?: number | null }[];
};

type AdminGroup = {
  id: number;
  name: string;
  description: string | null;
  category: string;
  memberCount: number;
  messageCount: number;
  createdAt: string;
};

type AdminGroupMessage = {
  id: number;
  content: string;
  senderName: string;
  senderRole: string;
  senderId: number;
  createdAt: string;
};

type AdminConversation = {
  id: number;
  participant1Name: string;
  participant2Name: string;
  participant1Role: string;
  participant2Role: string;
  lastMessage: string | null;
  messageCount: number;
  updatedAt: string;
};

function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  return fetch(path, { credentials: "include", ...options }).then(async (r) => {
    if (!r.ok) throw new Error(await r.text());
    return r.json() as Promise<T>;
  });
}

export default function Admin() {
  const [, setLocation] = useLocation();
  const { user, isAdmin, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (!user) {
    setLocation("/login");
    return null;
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-2">Access denied</h2>
        <p className="text-muted-foreground">You need admin permissions to view this page.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      <div className="flex items-center gap-3">
        <div className="bg-primary/10 p-3 rounded-xl">
          <ShieldCheck className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Full control over users, listings, chats, and messages.</p>
        </div>
      </div>

      <StatsRow />

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 max-w-3xl">
          <TabsTrigger value="overview" className="flex items-center gap-1">
            <Activity className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="listings" className="flex items-center gap-1">
            <Building2 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Listings</span>
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-1">
            <UsersIcon className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Users</span>
          </TabsTrigger>
          <TabsTrigger value="groups" className="flex items-center gap-1">
            <Hash className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Groups</span>
          </TabsTrigger>
          <TabsTrigger value="cultural" className="flex items-center gap-1">
            <BookOpen className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Tips</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab toast={toast} />
        </TabsContent>
        <TabsContent value="listings">
          <ListingsTab toast={toast} queryClient={queryClient} />
        </TabsContent>
        <TabsContent value="users">
          <UsersTab toast={toast} queryClient={queryClient} />
        </TabsContent>
        <TabsContent value="groups">
          <GroupsTab toast={toast} />
        </TabsContent>
        <TabsContent value="cultural">
          <CulturalTab toast={toast} queryClient={queryClient} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StatsRow() {
  const { data, isLoading } = useGetAdminStats();
  if (isLoading || !data) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }

  const statsData = data as typeof data & { totalGroups?: number; totalMessages?: number };

  const items = [
    { label: "Pending listings", value: data.pendingListings, icon: Clock, color: "text-amber-600" },
    { label: "Approved listings", value: data.approvedListings, icon: CheckCircle2, color: "text-emerald-600" },
    { label: "Pending uploaders", value: data.pendingUploaders, icon: UsersIcon, color: "text-amber-600" },
    { label: "Total users", value: data.totalUsers, icon: UsersIcon, color: "text-blue-600" },
    { label: "Group chats", value: (statsData.totalGroups ?? 0), icon: Hash, color: "text-purple-600" },
    { label: "Total messages", value: (statsData.totalMessages ?? 0), icon: MessageSquare, color: "text-indigo-600" },
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {items.map((it) => (
        <Card key={it.label}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="bg-muted p-2 rounded-lg shrink-0">
              <it.icon className={`h-5 w-5 ${it.color}`} />
            </div>
            <div>
              <div className="text-2xl font-bold leading-tight">{it.value}</div>
              <div className="text-xs text-muted-foreground">{it.label}</div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

type TabProps = { toast: ReturnType<typeof useToast>["toast"]; queryClient?: ReturnType<typeof useQueryClient> };

// ─── OVERVIEW TAB ─────────────────────────────────────────────────────────────
function OverviewTab({ toast }: TabProps) {
  const [data, setData] = useState<AdminOverview | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    apiFetch<AdminOverview>("/api/admin/overview")
      .then(setData)
      .catch(() => toast({ title: "Failed to load overview", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-48 w-full" /><Skeleton className="h-48 w-full" /></div>;
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Recent signups */}
      <Card className="md:col-span-1">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base">Recent Signups</CardTitle>
          <Button variant="ghost" size="icon" onClick={load}><RefreshCw className="h-4 w-4" /></Button>
        </CardHeader>
        <CardContent className="space-y-2">
          {data?.recentUsers.length === 0 && <p className="text-sm text-muted-foreground">No users yet.</p>}
          {data?.recentUsers.map((u) => (
            <div key={u.id} className="flex items-center justify-between gap-2 text-sm">
              <div className="min-w-0">
                <span className="font-medium truncate block">{u.name}</span>
                <span className="text-xs text-muted-foreground truncate block">{u.email}</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Badge variant="outline" className="text-xs">{u.role}</Badge>
                {!u.isApproved && <Badge className="bg-amber-100 text-amber-700 text-xs">pending</Badge>}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent listings */}
      <Card className="md:col-span-1">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Recent Uploads</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {data?.recentListings.length === 0 && <p className="text-sm text-muted-foreground">No listings yet.</p>}
          {data?.recentListings.map((l) => (
            <div key={l.id} className="flex items-center gap-2 text-sm">
              <div className="bg-muted p-1.5 rounded shrink-0">
                {(l as Listing & { type?: string }).type === "apartment" ? <Building2 className="h-3 w-3" /> : <Briefcase className="h-3 w-3" />}
              </div>
              <div className="min-w-0 flex-1">
                <span className="font-medium truncate block">{l.title}</span>
                <span className="text-xs text-muted-foreground">{l.city}</span>
              </div>
              <StatusBadge status={(l as Listing & { status?: string }).status} />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent messages */}
      <Card className="md:col-span-2 lg:col-span-1">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Recent Messages</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {data?.recentMessages.length === 0 && <p className="text-sm text-muted-foreground">No messages yet.</p>}
          {data?.recentMessages.map((m) => (
            <div key={m.id} className="text-sm border-l-2 border-primary/30 pl-2">
              <div className="flex items-center gap-1.5 mb-0.5">
                <span className="font-medium">{m.senderName}</span>
                {m.groupName && <Badge variant="outline" className="text-xs">{m.groupName}</Badge>}
                {!m.groupName && m.conversationId && <Badge variant="outline" className="text-xs">DM</Badge>}
              </div>
              <p className="text-muted-foreground text-xs line-clamp-1">{m.content}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

// ─── LISTINGS TAB ─────────────────────────────────────────────────────────────
function ListingsTab({ toast, queryClient }: TabProps) {
  const [statusFilter, setStatusFilter] = useState<"pending" | "approved" | "rejected" | "all">("all");
  const params = statusFilter === "all" ? undefined : { status: statusFilter };
  const { data: listings, isLoading } = useGetAdminListings(params);
  const approveMutation = useApproveListing();
  const deleteMutation = useAdminDeleteListing();
  const updateMutation = useUpdateListing();
  const [editing, setEditing] = useState<Listing | null>(null);
  const [editForm, setEditForm] = useState({
    title: "", description: "", price: "", city: "", location: "", contactInfo: "", images: "",
  });

  function startEdit(l: Listing) {
    setEditing(l);
    setEditForm({
      title: l.title,
      description: l.description,
      price: l.price != null ? String(l.price) : "",
      city: l.city,
      location: l.location ?? "",
      contactInfo: l.contactInfo ?? "",
      images: (l.images ?? []).join("\n"),
    });
  }

  async function handleSaveEdit() {
    if (!editing) return;
    try {
      const priceNum = editForm.price.trim() === "" ? null : Number(editForm.price);
      const images = editForm.images.split("\n").map((s) => s.trim()).filter(Boolean);
      await updateMutation.mutateAsync({
        id: editing.id,
        data: { title: editForm.title, description: editForm.description, price: priceNum, city: editForm.city, location: editForm.location || null, contactInfo: editForm.contactInfo || null, images },
      });
      toast({ title: "Listing updated" });
      setEditing(null);
      queryClient?.invalidateQueries({ queryKey: getGetAdminListingsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Update failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  async function handleAction(id: number, approve: boolean, reason?: string) {
    try {
      await approveMutation.mutateAsync({ id, data: { approve, reason: reason ?? null } });
      toast({ title: approve ? "Listing approved" : "Listing rejected" });
      queryClient?.invalidateQueries({ queryKey: getGetAdminListingsQueryKey() });
      queryClient?.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Action failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this listing permanently?")) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast({ title: "Listing deleted" });
      queryClient?.invalidateQueries({ queryKey: getGetAdminListingsQueryKey() });
      queryClient?.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Delete failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>All Listings</CardTitle>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <Skeleton className="h-24 w-full" />
        ) : !listings || listings.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No listings in this view.</p>
        ) : (
          listings.map((l: Listing) => (
            <div key={l.id} className="flex flex-col md:flex-row md:items-center justify-between gap-3 border rounded-lg p-3">
              <div className="flex items-start gap-3 min-w-0 flex-1">
                <div className="bg-muted p-2 rounded-lg shrink-0">
                  {(l as Listing & { type?: string }).type === "apartment" ? <Building2 className="h-4 w-4" /> : <Briefcase className="h-4 w-4" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="font-medium truncate">{l.title}</h4>
                    <StatusBadge status={(l as Listing & { status?: string }).status} />
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{l.description}</p>
                  <div className="text-xs text-muted-foreground mt-1">
                    {l.city} · {l.price ? `${l.price} ${l.currency}` : "—"} · source: {(l as Listing & { source?: string }).source}
                  </div>
                </div>
              </div>
              <div className="flex gap-2 shrink-0 flex-wrap">
                {(l as Listing & { status?: string }).status !== "approved" && (
                  <Button size="sm" onClick={() => handleAction(l.id, true)}>
                    <CheckCircle2 className="mr-1 h-4 w-4" /> Approve
                  </Button>
                )}
                {(l as Listing & { status?: string }).status !== "rejected" && (
                  <Button size="sm" variant="outline" onClick={() => { const r = prompt("Rejection reason (optional):") ?? ""; handleAction(l.id, false, r); }}>
                    <XCircle className="mr-1 h-4 w-4" /> Reject
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => startEdit(l)}>
                  <Edit2 className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => handleDelete(l.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))
        )}
      </CardContent>

      <Dialog open={editing !== null} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit listing</DialogTitle>
            <DialogDescription>Update content for this listing.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1"><Label>Title</Label><Input value={editForm.title} onChange={(e) => setEditForm({ ...editForm, title: e.target.value })} /></div>
            <div className="space-y-1"><Label>Description</Label><Textarea rows={4} value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Price</Label><Input type="number" value={editForm.price} onChange={(e) => setEditForm({ ...editForm, price: e.target.value })} /></div>
              <div className="space-y-1"><Label>City</Label><Input value={editForm.city} onChange={(e) => setEditForm({ ...editForm, city: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Location</Label><Input value={editForm.location} onChange={(e) => setEditForm({ ...editForm, location: e.target.value })} /></div>
              <div className="space-y-1"><Label>Contact info</Label><Input value={editForm.contactInfo} onChange={(e) => setEditForm({ ...editForm, contactInfo: e.target.value })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={handleSaveEdit} disabled={updateMutation.isPending}>{updateMutation.isPending ? "Saving..." : "Save changes"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function StatusBadge({ status }: { status: string | undefined }) {
  if (!status) return null;
  const variant: Record<string, string> = {
    approved: "bg-emerald-100 text-emerald-700",
    pending: "bg-amber-100 text-amber-700",
    rejected: "bg-rose-100 text-rose-700",
  };
  return <Badge className={variant[status] ?? ""}>{status}</Badge>;
}

// ─── USERS TAB ────────────────────────────────────────────────────────────────
function UsersTab({ toast, queryClient }: TabProps) {
  const { data: users, isLoading } = useGetAllUsers();
  const approveUser = useApproveUser();
  const updateRole = useUpdateUserRole();
  const deleteUser = useDeleteUser();
  const sortedUsers = [...(users ?? [])].sort((a, b) => {
    if (a.isApproved !== b.isApproved) return a.isApproved ? 1 : -1;
    return (b.createdAt ? new Date(b.createdAt).getTime() : 0) - (a.createdAt ? new Date(a.createdAt).getTime() : 0);
  });

  async function handleApprove(id: number) {
    try {
      await approveUser.mutateAsync({ id });
      toast({ title: "User approved — they can now log in" });
      queryClient?.invalidateQueries({ queryKey: getGetAllUsersQueryKey() });
      queryClient?.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  async function handleRole(id: number, role: "admin" | "uploader" | "student") {
    try {
      await updateRole.mutateAsync({ id, data: { role } });
      toast({ title: "Role updated" });
      queryClient?.invalidateQueries({ queryKey: getGetAllUsersQueryKey() });
      queryClient?.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this user? This cannot be undone.")) return;
    try {
      await deleteUser.mutateAsync({ id });
      toast({ title: "User deleted" });
      queryClient?.invalidateQueries({ queryKey: getGetAllUsersQueryKey() });
      queryClient?.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>All Users</CardTitle>
        <p className="text-sm text-muted-foreground">Pending users appear first. Use the role dropdown or Approve button to grant access.</p>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <Skeleton className="h-24 w-full" />
        ) : sortedUsers.length === 0 ? (
          <p className="text-sm text-muted-foreground">No users.</p>
        ) : (
          sortedUsers.map((u: PublicUser) => (
            <div key={u.id} className="flex flex-col md:flex-row md:items-center justify-between gap-3 border rounded-lg p-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium truncate">{u.name}</span>
                  <Badge variant="outline">{u.role}</Badge>
                  {!u.isApproved && <Badge className="bg-amber-100 text-amber-700">pending approval</Badge>}
                </div>
                <div className="text-sm text-muted-foreground truncate">{u.email}</div>
                <div className="text-xs text-muted-foreground">Joined {u.createdAt ? new Date(u.createdAt).toLocaleString() : "recently"}</div>
              </div>
              <div className="flex flex-wrap gap-2 shrink-0">
                {!u.isApproved && (
                  <Button size="sm" onClick={() => handleApprove(u.id)}>
                    <CheckCircle2 className="mr-1 h-4 w-4" /> Approve
                  </Button>
                )}
                <Select value={u.role} onValueChange={(v) => handleRole(u.id, v as "admin" | "uploader" | "student")}>
                  <SelectTrigger className="w-32 h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="uploader">Uploader</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="sm" variant="ghost" onClick={() => handleDelete(u.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

// ─── GROUPS TAB ───────────────────────────────────────────────────────────────
function GroupsTab({ toast }: TabProps) {
  const [groups, setGroups] = useState<AdminGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeGroup, setActiveGroup] = useState<AdminGroup | null>(null);
  const [messages, setMessages] = useState<AdminGroupMessage[]>([]);
  const [msgsLoading, setMsgsLoading] = useState(false);

  const loadGroups = useCallback(() => {
    setLoading(true);
    apiFetch<AdminGroup[]>("/api/admin/groups")
      .then(setGroups)
      .catch(() => toast({ title: "Failed to load groups", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, [toast]);

  useEffect(() => { loadGroups(); }, [loadGroups]);

  const loadMessages = useCallback((group: AdminGroup) => {
    setActiveGroup(group);
    setMsgsLoading(true);
    apiFetch<AdminGroupMessage[]>(`/api/admin/groups/${group.id}/messages`)
      .then(setMessages)
      .catch(() => toast({ title: "Failed to load messages", variant: "destructive" }))
      .finally(() => setMsgsLoading(false));
  }, [toast]);

  async function deleteMessage(groupId: number, msgId: number) {
    try {
      await apiFetch(`/api/admin/groups/${groupId}/messages/${msgId}`, { method: "DELETE" });
      toast({ title: "Message deleted" });
      setMessages((prev) => prev.filter((m) => m.id !== msgId));
      loadGroups();
    } catch {
      toast({ title: "Failed to delete message", variant: "destructive" });
    }
  }

  async function deleteGroup(groupId: number) {
    if (!confirm("Delete this entire group and all its messages?")) return;
    try {
      await apiFetch(`/api/admin/groups/${groupId}`, { method: "DELETE" });
      toast({ title: "Group deleted" });
      setGroups((prev) => prev.filter((g) => g.id !== groupId));
      if (activeGroup?.id === groupId) { setActiveGroup(null); setMessages([]); }
    } catch {
      toast({ title: "Failed to delete group", variant: "destructive" });
    }
  }

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      {/* Group list */}
      <Card className="lg:col-span-1">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base">Group Chats</CardTitle>
          <Button variant="ghost" size="icon" onClick={loadGroups}><RefreshCw className="h-4 w-4" /></Button>
        </CardHeader>
        <CardContent className="space-y-2 p-3">
          {loading ? (
            <Skeleton className="h-24 w-full" />
          ) : groups.length === 0 ? (
            <p className="text-sm text-muted-foreground">No groups.</p>
          ) : (
            groups.map((g) => (
              <div
                key={g.id}
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${activeGroup?.id === g.id ? "bg-primary/10 border-primary/30" : "hover:bg-muted"}`}
                onClick={() => loadMessages(g)}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm truncate">{g.name}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                      <span>{g.memberCount} members</span>
                      <span>·</span>
                      <span>{g.messageCount} msgs</span>
                    </div>
                  </div>
                  <Button
                    size="sm" variant="ghost"
                    onClick={(e) => { e.stopPropagation(); deleteGroup(g.id); }}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Messages panel */}
      <Card className="lg:col-span-2">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">
            {activeGroup ? `#${activeGroup.name} — messages` : "Select a group to moderate"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 max-h-[500px] overflow-y-auto">
          {!activeGroup && (
            <div className="flex flex-col items-center py-12 gap-2 text-center">
              <Hash className="h-10 w-10 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">Click a group on the left to view and moderate its messages.</p>
            </div>
          )}
          {msgsLoading && <Skeleton className="h-24 w-full" />}
          {!msgsLoading && activeGroup && messages.length === 0 && (
            <p className="text-sm text-muted-foreground py-4 text-center">No messages in this group.</p>
          )}
          {!msgsLoading && messages.map((m) => (
            <div key={m.id} className="flex items-start gap-3 p-2 rounded-lg border group hover:bg-muted/50">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-medium text-sm">{m.senderName}</span>
                  <Badge variant="outline" className="text-xs">{m.senderRole}</Badge>
                  <span className="text-xs text-muted-foreground">{new Date(m.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-sm text-muted-foreground">{m.content}</p>
              </div>
              <Button
                size="sm" variant="ghost"
                className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                onClick={() => activeGroup && deleteMessage(activeGroup.id, m.id)}
              >
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

// ─── CULTURAL TIPS TAB ────────────────────────────────────────────────────────
function CulturalTab({ toast, queryClient }: TabProps) {
  const { data: tips, isLoading } = useGetCulturalTips();
  const createTip = useCreateCulturalTip();
  const updateTip = useUpdateCulturalTip();
  const deleteTip = useDeleteCulturalTip();
  const [editing, setEditing] = useState<CulturalTip | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", content: "", category: "general", icon: "" });

  function startCreate() { setEditing(null); setForm({ title: "", content: "", category: "general", icon: "" }); setOpen(true); }
  function startEdit(tip: CulturalTip) { setEditing(tip); setForm({ title: tip.title, content: tip.content, category: tip.category, icon: tip.icon ?? "" }); setOpen(true); }

  async function handleSave() {
    try {
      const payload = { title: form.title, content: form.content, category: form.category, icon: form.icon || null };
      if (editing) {
        await updateTip.mutateAsync({ id: editing.id, data: payload });
        toast({ title: "Tip updated" });
      } else {
        await createTip.mutateAsync({ data: payload });
        toast({ title: "Tip created" });
      }
      setOpen(false);
      queryClient?.invalidateQueries({ queryKey: getGetCulturalTipsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Save failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this tip?")) return;
    try {
      await deleteTip.mutateAsync({ id });
      toast({ title: "Tip deleted" });
      queryClient?.invalidateQueries({ queryKey: getGetCulturalTipsQueryKey() });
    } catch (err: unknown) {
      toast({ title: "Failed", description: err instanceof Error ? err.message : "", variant: "destructive" });
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Cultural Tips</CardTitle>
        <Button size="sm" onClick={startCreate}><Plus className="mr-1 h-4 w-4" />New tip</Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <Skeleton className="h-24 w-full" />
        ) : !tips || tips.length === 0 ? (
          <p className="text-sm text-muted-foreground">No tips yet.</p>
        ) : (
          tips.map((t: CulturalTip) => (
            <div key={t.id} className="flex items-start justify-between gap-3 border rounded-lg p-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <BookOpen className="h-4 w-4 text-primary" />
                  <h4 className="font-medium truncate">{t.title}</h4>
                  <Badge variant="outline">{t.category}</Badge>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{t.content}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button size="sm" variant="ghost" onClick={() => startEdit(t)}><Edit2 className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => handleDelete(t.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </div>
          ))
        )}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit tip" : "New cultural tip"}</DialogTitle>
            <DialogDescription>Share guidance for international students.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1"><Label>Title</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div className="space-y-1">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General</SelectItem>
                  <SelectItem value="housing">Housing</SelectItem>
                  <SelectItem value="transport">Transport</SelectItem>
                  <SelectItem value="food">Food</SelectItem>
                  <SelectItem value="customs">Customs</SelectItem>
                  <SelectItem value="language">Language</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1"><Label>Icon (optional emoji)</Label><Input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} maxLength={4} /></div>
            <div className="space-y-1"><Label>Content</Label><Textarea rows={5} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? "Save changes" : "Create tip"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
