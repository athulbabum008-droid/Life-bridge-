import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { User, Star, CheckCircle, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useGetUser,
  useUpdateUser,
  useGetScenarioProgress,
  useGetChecklist,
  getGetUserQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";


const schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  country: z.string().optional(),
  university: z.string().optional(),
  bio: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function Profile() {
  const { user: authUser } = useAuth();
  const CURRENT_USER_ID = authUser?.id ?? 0;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user, isLoading: userLoading } = useGetUser(CURRENT_USER_ID);
  const { data: progress } = useGetScenarioProgress({ userId: CURRENT_USER_ID });
  const { data: checklist } = useGetChecklist({ userId: CURRENT_USER_ID });
  const updateUser = useUpdateUser();

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    values: {
      name: user?.name ?? "",
      country: user?.country ?? "",
      university: user?.university ?? "",
      bio: user?.bio ?? "",
    },
  });

  const onSubmit = (data: FormData) => {
    updateUser.mutate(
      {
        id: CURRENT_USER_ID,
        data: {
          name: data.name,
          country: data.country ?? null,
          university: data.university ?? null,
          bio: data.bio ?? null,
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetUserQueryKey(CURRENT_USER_ID) });
          toast({ title: "Profile updated!" });
        },
        onError: () => {
          toast({ title: "Failed to update profile", variant: "destructive" });
        },
      }
    );
  };

  const completedScenarios = progress?.filter((p) => p.completedAt).length ?? 0;
  const totalScenarios = progress?.length ?? 0;
  const completedChecklist = checklist?.filter((i) => i.isCompleted).length ?? 0;
  const totalChecklist = checklist?.length ?? 0;

  if (userLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-2xl space-y-6">
        <Skeleton className="h-32 rounded-2xl" />
        <Skeleton className="h-64 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl space-y-6">
      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-5">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-2xl font-bold">
                {user?.name?.split(" ").map((n) => n[0]).join("").substring(0, 2) ?? "?"}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-2xl font-bold">{user?.name ?? "Student"}</h1>
                {user?.isVerified && (
                  <Badge className="bg-green-100 text-green-700 text-xs">Verified</Badge>
                )}
              </div>
              {user?.country && <p className="text-muted-foreground">{user.country}</p>}
              {user?.university && <p className="text-sm text-muted-foreground">{user.university}</p>}
              {user?.bio && <p className="text-sm mt-2">{user.bio}</p>}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <StatCard
          icon={<Star className="h-5 w-5 text-yellow-500" />}
          value={`${completedScenarios}/${totalScenarios}`}
          label="Scenarios"
          color="bg-yellow-50"
        />
        <StatCard
          icon={<CheckCircle className="h-5 w-5 text-green-500" />}
          value={`${completedChecklist}/${totalChecklist}`}
          label="Checklist"
          color="bg-green-50"
        />
        <StatCard
          icon={<BookOpen className="h-5 w-5 text-primary" />}
          value={String(progress?.reduce((sum, p) => sum + p.totalMessages, 0) ?? 0)}
          label="Messages"
          color="bg-primary/5"
        />
      </div>

      {/* Edit Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <User className="h-5 w-5 text-primary" />
            Edit Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="country"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Country of Origin</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. India" {...field} data-testid="input-country" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="university"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>University</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. University of Latvia" {...field} data-testid="input-university" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bio</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Tell other students about yourself..." className="min-h-20" {...field} data-testid="input-bio" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-primary to-accent text-white"
                disabled={updateUser.isPending}
                data-testid="button-save-profile"
              >
                {updateUser.isPending ? "Saving..." : "Save Profile"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ icon, value, label, color }: { icon: React.ReactNode; value: string; label: string; color: string }) {
  return (
    <div className={`${color} rounded-xl p-4 text-center border`}>
      <div className="flex justify-center mb-2">{icon}</div>
      <p className="text-xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
