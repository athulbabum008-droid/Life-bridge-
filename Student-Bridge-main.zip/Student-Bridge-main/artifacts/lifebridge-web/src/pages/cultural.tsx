import { useState } from "react";
import { CheckCircle, Circle, Map, Info, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
  useGetCulturalTips,
  useGetChecklist,
  useUpdateChecklistItem,
  getGetChecklistQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";


const CATEGORY_ICONS: Record<string, string> = {
  Banking: "🏦",
  Transport: "🚌",
  Healthcare: "🏥",
  Social: "👥",
  Documents: "📄",
  Tax: "📊",
  Tips: "💡",
  "Student Life": "🎓",
};

const CATEGORY_COLORS: Record<string, string> = {
  Banking: "bg-blue-100 text-blue-700",
  Transport: "bg-green-100 text-green-700",
  Healthcare: "bg-red-100 text-red-700",
  Social: "bg-purple-100 text-purple-700",
  Documents: "bg-yellow-100 text-yellow-700",
  Tax: "bg-orange-100 text-orange-700",
  Tips: "bg-teal-100 text-teal-700",
  "Student Life": "bg-indigo-100 text-indigo-700",
};

const CHECKLIST_COLORS: Record<string, string> = {
  Education: "bg-blue-50 text-blue-700 border-blue-200",
  Housing: "bg-green-50 text-green-700 border-green-200",
  Documents: "bg-yellow-50 text-yellow-700 border-yellow-200",
  Finance: "bg-purple-50 text-purple-700 border-purple-200",
  Communication: "bg-pink-50 text-pink-700 border-pink-200",
  Transport: "bg-teal-50 text-teal-700 border-teal-200",
  Healthcare: "bg-red-50 text-red-700 border-red-200",
  "Student Life": "bg-indigo-50 text-indigo-700 border-indigo-200",
  General: "bg-gray-50 text-gray-700 border-gray-200",
};

export default function Cultural() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: tips, isLoading: tipsLoading } = useGetCulturalTips({
    country: "Latvia",
    category: selectedCategory === "all" ? undefined : selectedCategory,
  });

  const { data: checklist, isLoading: checklistLoading } = useGetChecklist({ userId: CURRENT_USER_ID });
  const updateItem = useUpdateChecklistItem();

  const completedCount = checklist?.filter((i) => i.isCompleted).length ?? 0;
  const totalCount = checklist?.length ?? 0;
  const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const categories = Array.from(new Set(tips?.map((t) => t.category) ?? []));

  const handleToggle = (id: number, current: boolean) => {
    updateItem.mutate(
      { id, data: { isCompleted: !current } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetChecklistQueryKey({ userId: CURRENT_USER_ID }) });
          toast({ title: !current ? "Task completed!" : "Task unchecked" });
        },
      }
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Cultural Guide & Checklist</h1>
        <p className="text-muted-foreground">Everything you need to know to settle into life in Latvia</p>
      </div>

      {/* Arrival Checklist */}
      <section className="mb-10">
        <div className="bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/10 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-primary" />
              Arrival Checklist
            </h2>
            <span className="text-sm font-medium text-muted-foreground">{completedCount}/{totalCount} done</span>
          </div>
          <Progress value={progress} className="h-2 mb-6" />

          {checklistLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
            </div>
          ) : checklist && checklist.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {checklist.map((item) => (
                <div
                  key={item.id}
                  data-testid={`checklist-item-${item.id}`}
                  className={`flex items-start gap-3 p-4 rounded-xl border transition-all cursor-pointer hover:shadow-sm ${
                    item.isCompleted ? "opacity-70 bg-green-50/50 border-green-200" : "bg-card hover:border-primary/30"
                  }`}
                  onClick={() => handleToggle(item.id, item.isCompleted)}
                >
                  <div className="mt-0.5 flex-shrink-0">
                    {item.isCompleted ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-muted-foreground/40" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className={`font-medium text-sm ${item.isCompleted ? "line-through text-muted-foreground" : ""}`}>
                        {item.title}
                      </p>
                      <Badge
                        variant="outline"
                        className={`text-xs hidden sm:inline-flex ${CHECKLIST_COLORS[item.category] ?? ""}`}
                      >
                        {item.category}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center py-8 gap-2">
              <CheckCircle className="h-8 w-8 text-muted-foreground/30" />
              <p className="text-muted-foreground text-sm">No checklist items yet</p>
            </div>
          )}
        </div>
      </section>

      {/* Cultural Tips */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Map className="h-5 w-5 text-accent" />
            Latvia Guide
          </h2>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-44" data-testid="select-category">
              <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {tipsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />)}
          </div>
        ) : tips && tips.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tips.map((tip) => (
              <Card key={tip.id} data-testid={`card-tip-${tip.id}`} className="hover:shadow-sm transition-all">
                <CardContent className="p-5">
                  <div className="flex items-start gap-3">
                    <div className="p-2.5 rounded-xl bg-muted flex-shrink-0 text-lg">
                      {CATEGORY_ICONS[tip.category] ?? "ℹ️"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-sm">{tip.title}</p>
                        <Badge
                          className={`text-xs flex-shrink-0 ${CATEGORY_COLORS[tip.category] ?? "bg-gray-100 text-gray-700"}`}
                        >
                          {tip.category}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{tip.content}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center py-10 gap-2">
            <Info className="h-10 w-10 text-muted-foreground/30" />
            <p className="text-muted-foreground">No tips found for this category</p>
          </div>
        )}
      </section>
    </div>
  );
}
