import { useState } from "react";
import { Link } from "wouter";
import { Briefcase, MapPin, Plus, ExternalLink, DollarSign, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetListings, useGetSslvJobs } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";

export default function Jobs() {
  const { user } = useAuth();
  const [city, setCity] = useState("");
  const [search, setSearch] = useState("");

  const { data: userJobs, isLoading: userLoading } = useGetListings({ type: "job", city: city || undefined });
  const { data: sslvJobs, isLoading: sslvLoading } = useGetSslvJobs({ city: city || "riga" });

  const filteredUserJobs = userJobs?.listings?.filter((j) =>
    !search || j.title.toLowerCase().includes(search.toLowerCase())
  );

  const filteredSslvJobs = sslvJobs?.filter((j) =>
    !search || j.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Student Jobs</h1>
          <p className="text-muted-foreground mt-1">Part-time and flexible jobs for international students</p>
        </div>
        {(user?.role === "uploader" || user?.role === "admin") && (
          <Link href="/jobs/new">
            <Button className="bg-gradient-to-r from-primary to-accent text-white">
              <Plus className="mr-2 h-4 w-4" /> Post Job
            </Button>
          </Link>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-6 bg-card border rounded-xl p-4">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search jobs..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-jobs"
          />
        </div>
        <Select value={city || "all"} onValueChange={(v) => setCity(v === "all" ? "" : v)}>
          <SelectTrigger className="w-40" data-testid="select-city-jobs">
            <SelectValue placeholder="City" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All cities</SelectItem>
            <SelectItem value="Riga">Riga</SelectItem>
            <SelectItem value="Jurmala">Jurmala</SelectItem>
            <SelectItem value="Liepaja">Liepaja</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="sslv">
        <TabsList className="mb-6">
          <TabsTrigger value="sslv">SS.lv Jobs <Badge variant="secondary" className="ml-2 text-xs">{sslvJobs?.length ?? 0}</Badge></TabsTrigger>
          <TabsTrigger value="user">Student Posts <Badge variant="secondary" className="ml-2 text-xs">{filteredUserJobs?.length ?? 0}</Badge></TabsTrigger>
        </TabsList>

        <TabsContent value="sslv">
          {sslvLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
            </div>
          ) : filteredSslvJobs && filteredSslvJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredSslvJobs.map((job) => (
                <Card key={job.id} className="group hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-2">
                      <Badge className="bg-orange-500/10 text-orange-600 border-orange-200 text-xs">SS.lv</Badge>
                      {job.price && <span className="text-sm font-bold text-green-600">{job.price}</span>}
                    </div>
                    <p className="font-semibold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">{job.title}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mb-3">
                      <MapPin className="h-3 w-3" /> {job.location}
                    </p>
                    <a href={job.url} target="_blank" rel="noopener noreferrer">
                      <Button size="sm" variant="outline" className="w-full text-xs">
                        <ExternalLink className="mr-1 h-3 w-3" /> View on SS.lv
                      </Button>
                    </a>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center py-16 gap-3">
              <Briefcase className="h-12 w-12 text-muted-foreground/30" />
              <p className="text-muted-foreground">No SS.lv jobs found</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="user">
          {userLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
            </div>
          ) : filteredUserJobs && filteredUserJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredUserJobs.map((job) => (
                <Card key={job.id} data-testid={`card-job-${job.id}`} className="group hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-2">
                      <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">Student Post</Badge>
                      {job.price && (
                        <span className="text-sm font-bold text-green-600">
                          <DollarSign className="inline h-3 w-3" />{job.price} EUR
                        </span>
                      )}
                    </div>
                    <p className="font-semibold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">{job.title}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{job.description}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mb-3">
                      <MapPin className="h-3 w-3" /> {job.city}
                    </p>
                    {job.contactInfo && (
                      <p className="text-xs text-primary font-medium">{job.contactInfo}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center py-16 gap-3">
              <Briefcase className="h-12 w-12 text-muted-foreground/30" />
              <p className="text-muted-foreground">No student job posts yet. Be the first!</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
