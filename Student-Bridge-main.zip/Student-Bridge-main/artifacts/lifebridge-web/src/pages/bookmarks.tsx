import { Bookmark, Home as HomeIcon, Briefcase, MapPin, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetBookmarks, useRemoveBookmark, getGetBookmarksQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";


export default function Bookmarks() {
  const { user } = useAuth();
  const CURRENT_USER_ID = user?.id ?? 0;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: bookmarks, isLoading } = useGetBookmarks({ userId: CURRENT_USER_ID });
  const removeBookmark = useRemoveBookmark();

  const handleRemove = (id: number) => {
    removeBookmark.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetBookmarksQueryKey({ userId: CURRENT_USER_ID }) });
          toast({ title: "Bookmark removed" });
        },
      }
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-1">Saved Listings</h1>
        <p className="text-muted-foreground">{bookmarks?.length ?? 0} saved items</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
        </div>
      ) : bookmarks && bookmarks.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {bookmarks.map((bookmark) => {
            const listing = bookmark.listing;
            if (!listing) return null;
            return (
              <Card key={bookmark.id} data-testid={`card-bookmark-${bookmark.id}`} className="group hover:shadow-md transition-all duration-200 hover:-translate-y-0.5 overflow-hidden">
                <div className="h-28 bg-gradient-to-br from-primary/10 to-accent/5 flex items-center justify-center">
                  {listing.type === "apartment" ? (
                    <HomeIcon className="h-10 w-10 text-primary/30" />
                  ) : (
                    <Briefcase className="h-10 w-10 text-accent/30" />
                  )}
                </div>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-1">
                    <Badge variant="outline" className="text-xs">
                      {listing.type === "apartment" ? "Housing" : "Job"}
                    </Badge>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-muted-foreground hover:text-destructive -mr-1 -mt-1"
                      onClick={() => handleRemove(bookmark.id)}
                      data-testid={`button-remove-bookmark-${bookmark.id}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <p className="font-semibold text-sm mb-1 line-clamp-2">{listing.title}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{listing.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> {listing.city}
                    </span>
                    {listing.price && (
                      <span className="text-sm font-bold text-primary">{listing.price} EUR</span>
                    )}
                  </div>
                  {listing.contactInfo && (
                    <p className="text-xs text-primary mt-2 font-medium">{listing.contactInfo}</p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="p-6 rounded-full bg-muted">
            <Bookmark className="h-12 w-12 text-muted-foreground/30" />
          </div>
          <div className="text-center">
            <p className="font-semibold text-lg mb-1">No saved listings yet</p>
            <p className="text-muted-foreground text-sm">Save apartments and jobs to find them easily later</p>
          </div>
        </div>
      )}
    </div>
  );
}
