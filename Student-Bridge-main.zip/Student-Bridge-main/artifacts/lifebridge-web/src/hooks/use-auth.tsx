import { createContext, useContext, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetCurrentUser,
  useLoginUser,
  useLogoutUser,
  useRegisterUser,
  getGetCurrentUserQueryKey,
} from "@workspace/api-client-react";
import type { PublicUser } from "@workspace/api-client-react";

type LoginInput =
  | { method: "email"; email: string; password: string }
  | { method: "phone"; phone: string; password: string };

type AuthContextValue = {
  user: PublicUser | null;
  isLoading: boolean;
  isAdmin: boolean;
  isUploader: boolean;
  isStudent: boolean;
  login: (input: LoginInput) => Promise<PublicUser>;
  register: (input: {
    email: string;
    password: string;
    name: string;
    role: "student" | "uploader";
    phone?: string;
    country?: string;
    university?: string;
  }) => Promise<{ user: PublicUser; pendingApproval: boolean }>;
  logout: () => Promise<void>;
  refresh: () => void;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const { data, isLoading } = useGetCurrentUser({
    query: { retry: false, staleTime: 60_000 },
  });

  const loginMutation = useLoginUser();
  const registerMutation = useRegisterUser();
  const logoutMutation = useLogoutUser();

  const user = (data as PublicUser | undefined) ?? null;

  const value: AuthContextValue = {
    user,
    isLoading,
    isAdmin: user?.role === "admin",
    isUploader: user?.role === "uploader",
    isStudent: user?.role === "student",
    async login(input) {
      const data =
        input.method === "phone"
          ? { phone: input.phone, password: input.password }
          : { email: input.email, password: input.password };
      const res = await loginMutation.mutateAsync({ data });
      await queryClient.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() });
      return res.user as PublicUser;
    },
    async register(input) {
      const res = await registerMutation.mutateAsync({ data: input });
      if (!res.pendingApproval) {
        await queryClient.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() });
      }
      return res as { user: PublicUser; pendingApproval: boolean };
    },
    async logout() {
      await logoutMutation.mutateAsync();
      queryClient.setQueryData(getGetCurrentUserQueryKey(), null);
      await queryClient.invalidateQueries();
    },
    refresh() {
      queryClient.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() });
    },
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
