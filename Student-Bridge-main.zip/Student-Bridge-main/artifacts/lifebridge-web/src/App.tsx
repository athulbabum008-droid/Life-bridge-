import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { MainLayout } from "@/components/layout/main-layout";
import { Suspense, lazy, useEffect } from "react";
import { Spinner } from "@/components/ui/spinner";
import { AuthProvider, useAuth } from "@/hooks/use-auth";

// Lazy load pages for better performance
const Home = lazy(() => import("@/pages/home"));
const Housing = lazy(() => import("@/pages/housing"));
const HousingNew = lazy(() => import("@/pages/housing-new"));
const Jobs = lazy(() => import("@/pages/jobs"));
const JobsNew = lazy(() => import("@/pages/jobs-new"));
const Simulate = lazy(() => import("@/pages/simulate"));
const Community = lazy(() => import("@/pages/community"));
const Chat = lazy(() => import("@/pages/chat"));
const Cultural = lazy(() => import("@/pages/cultural"));
const Bookmarks = lazy(() => import("@/pages/bookmarks"));
const Profile = lazy(() => import("@/pages/profile"));
const Login = lazy(() => import("@/pages/login"));
const Register = lazy(() => import("@/pages/register"));
const Admin = lazy(() => import("@/pages/admin"));
const NotFound = lazy(() => import("@/pages/not-found"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

function LoadingFallback() {
  return (
    <div className="flex h-[50vh] w-full items-center justify-center">
      <Spinner className="size-8 text-primary" />
    </div>
  );
}

const PROTECTED_ROUTES = ["/profile", "/bookmarks", "/chat", "/housing/new", "/jobs/new", "/admin"];

function ProtectedSwitch() {
  const [location, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (isLoading) return;
    const isProtected = PROTECTED_ROUTES.some((p) => location === p || location.startsWith(`${p}/`));
    if (isProtected && !user) {
      setLocation("/login");
    }
  }, [location, user, isLoading, setLocation]);

  return (
    <Suspense fallback={<LoadingFallback />}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/admin" component={Admin} />
        <Route path="/housing" component={Housing} />
        <Route path="/housing/new" component={HousingNew} />
        <Route path="/jobs" component={Jobs} />
        <Route path="/jobs/new" component={JobsNew} />
        <Route path="/simulate" component={Simulate} />
        <Route path="/community" component={Community} />
        <Route path="/chat" component={Chat} />
        <Route path="/cultural" component={Cultural} />
        <Route path="/bookmarks" component={Bookmarks} />
        <Route path="/profile" component={Profile} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <MainLayout>
              <ProtectedSwitch />
            </MainLayout>
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
