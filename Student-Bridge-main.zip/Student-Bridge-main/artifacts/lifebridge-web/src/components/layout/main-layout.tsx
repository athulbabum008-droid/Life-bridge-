import { Link, useLocation } from "wouter";
import { Building2, Briefcase, BookOpen, Users, MessageSquare, Map, Bookmark, User as UserIcon, Home as HomeIcon, ShieldCheck, LogOut, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

const navItems = [
  { path: "/", label: "Home", icon: HomeIcon },
  { path: "/housing", label: "Housing", icon: Building2 },
  { path: "/jobs", label: "Jobs", icon: Briefcase },
  { path: "/simulate", label: "Practice", icon: BookOpen },
  { path: "/community", label: "Community", icon: Users },
  { path: "/chat", label: "Messages", icon: MessageSquare },
  { path: "/cultural", label: "Guide", icon: Map },
];

export function MainLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { user, isAdmin, logout } = useAuth();
  const { toast } = useToast();

  async function handleLogout() {
    await logout();
    toast({ title: "Signed out" });
    setLocation("/login");
  }

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/90 backdrop-blur-xl">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 transition-opacity hover:opacity-90">
            <div className="bg-primary/15 p-2 rounded-xl ring-1 ring-primary/30 glow-blue">
              <Building2 className="h-5 w-5 text-primary" />
            </div>
            <span className="font-bold text-xl tracking-tight gradient-text">LifeBridge</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-0.5">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={cn(
                  "px-3 py-2 rounded-md text-sm font-medium transition-all hover:bg-muted hover:text-primary",
                  location === item.path
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "text-muted-foreground",
                )}
              >
                <div className="flex items-center gap-2">
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </div>
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {isAdmin && (
              <Link href="/admin" className="hidden md:block">
                <Button variant={location === "/admin" ? "default" : "ghost"} size="sm">
                  <ShieldCheck className="mr-1 h-4 w-4" />
                  Admin
                </Button>
              </Link>
            )}
            {user ? (
              <>
                <Link href="/bookmarks" className="hidden md:block">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={cn("rounded-full", location === "/bookmarks" && "bg-muted text-primary")}
                  >
                    <Bookmark className="h-5 w-5" />
                  </Button>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full">
                      <UserIcon className="h-5 w-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>
                      <div className="flex flex-col">
                        <span className="font-medium truncate">{user.name}</span>
                        <span className="text-xs text-muted-foreground truncate">{user.email}</span>
                        <Badge variant="outline" className="mt-1 w-fit text-xs">
                          {user.role}
                        </Badge>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/profile">
                        <UserIcon className="mr-2 h-4 w-4" />
                        Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/bookmarks">
                        <Bookmark className="mr-2 h-4 w-4" />
                        Bookmarks
                      </Link>
                    </DropdownMenuItem>
                    {isAdmin && (
                      <DropdownMenuItem asChild>
                        <Link href="/admin">
                          <ShieldCheck className="mr-2 h-4 w-4" />
                          Admin
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="ghost" size="sm">
                    <LogIn className="mr-1 h-4 w-4" />
                    Sign in
                  </Button>
                </Link>
                <Link href="/register" className="hidden sm:block">
                  <Button size="sm">Get started</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <nav className="md:hidden sticky bottom-0 z-50 w-full border-t border-border/50 bg-background/95 backdrop-blur-xl pb-safe">
        <div className="flex items-center justify-around p-2">
          {navItems.slice(0, 5).map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={cn(
                "flex flex-col items-center p-2 rounded-lg text-xs transition-all",
                location === item.path
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-primary",
              )}
            >
              <item.icon className="h-5 w-5 mb-1" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
