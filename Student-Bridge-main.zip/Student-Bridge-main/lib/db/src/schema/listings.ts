import { pgTable, text, serial, boolean, timestamp, integer, numeric, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const listingsTable = pgTable("listings", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'apartment' | 'job'
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: numeric("price"),
  currency: text("currency").notNull().default("EUR"),
  city: text("city").notNull(),
  location: text("location"),
  images: json("images").$type<string[]>().notNull().default([]),
  contactInfo: text("contact_info"),
  source: text("source").notNull().default("user"), // 'sslv' | 'user'
  status: text("status").notNull().default("approved"), // 'pending' | 'approved' | 'rejected'
  rejectionReason: text("rejection_reason"),
  userId: integer("user_id").references(() => usersTable.id),
  isActive: boolean("is_active").notNull().default(true),
  reportCount: integer("report_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertListingSchema = createInsertSchema(listingsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Listing = typeof listingsTable.$inferSelect;
