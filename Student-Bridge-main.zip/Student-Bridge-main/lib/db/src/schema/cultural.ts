import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const culturalTipsTable = pgTable("cultural_tips", {
  id: serial("id").primaryKey(),
  country: text("country").notNull(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  icon: text("icon").notNull().default("Info"),
});

export const checklistItemsTable = pgTable("checklist_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  order: integer("order").notNull().default(0),
});

export const bookmarksTable = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  listingId: integer("listing_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCulturalTipSchema = createInsertSchema(culturalTipsTable).omit({ id: true });
export const insertChecklistItemSchema = createInsertSchema(checklistItemsTable).omit({ id: true });
export const insertBookmarkSchema = createInsertSchema(bookmarksTable).omit({ id: true, createdAt: true });

export type CulturalTip = typeof culturalTipsTable.$inferSelect;
export type ChecklistItem = typeof checklistItemsTable.$inferSelect;
export type Bookmark = typeof bookmarksTable.$inferSelect;
export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
