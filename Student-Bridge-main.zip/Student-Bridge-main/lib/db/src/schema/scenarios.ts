import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const scenariosTable = pgTable("scenarios", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull().default("beginner"),
  systemPrompt: text("system_prompt").notNull(),
  icon: text("icon").notNull().default("MessageSquare"),
});

export const scenarioProgressTable = pgTable("scenario_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  scenarioId: integer("scenario_id").notNull().references(() => scenariosTable.id),
  completedAt: timestamp("completed_at"),
  totalMessages: integer("total_messages").notNull().default(0),
  lastScore: integer("last_score"),
});

export const insertScenarioSchema = createInsertSchema(scenariosTable).omit({ id: true });
export const insertScenarioProgressSchema = createInsertSchema(scenarioProgressTable).omit({ id: true });

export type Scenario = typeof scenariosTable.$inferSelect;
export type ScenarioProgress = typeof scenarioProgressTable.$inferSelect;
export type InsertScenarioProgress = z.infer<typeof insertScenarioProgressSchema>;
